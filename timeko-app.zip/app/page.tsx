"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Clock, Users, DollarSign, Calendar, LogOut, Settings } from "lucide-react"
import { EmployeeManagement } from "@/components/employee-management"
import { TimeTracking } from "@/components/time-tracking"
import { PayrollGenerator } from "@/components/payroll-generator"
import { AttendanceOverview } from "@/components/attendance-overview"
import { ScheduleManagement } from "@/components/schedule-management"
import { LoginForm } from "@/components/login-form"
import { EmployeePayrollView } from "@/components/employee-payroll-view"
import { DeductionManagement } from "@/components/deduction-management"
import { AllowanceManagement } from "@/components/allowance-management"
import { SettingsComponent } from "@/components/settings"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface User {
  id: string
  name: string
  email: string
  role: "admin" | "employee"
  employeeId?: string
}

interface Employee {
  id: string
  name: string
  email: string
  hourlyRate: number
  position: string
  isActive: boolean
  role: "admin" | "employee"
  pincode: string
}

interface Schedule {
  id: string
  employeeId: string
  date: string
  startTime: string
  endTime: string
  dayType: "regular" | "sunday" | "holiday"
  isRestDay: boolean
}

interface TimeEntry {
  id: string
  employeeId: string
  date: string
  clockIn?: string
  clockOut?: string
  hoursWorked: number
  isLate: boolean
  lateMinutes: number
  lateReason?: string
  isAbsent: boolean
  status: "on-time" | "late" | "absent"
  clockInComment?: string
  clockOutComment?: string
  adminOverride?: boolean
}

interface CashAdvance {
  id: string
  employeeId: string
  date: string
  amount: number
  remarks: string
  isPaid: boolean
}

interface EmployeeDeduction {
  id: string
  employeeId: string
  name: string
  type: "fixed" | "percentage"
  amount: number
  isActive: boolean
}

interface EmployeeAllowance {
  id: string
  employeeId: string
  weekStartDate: string
  amount: number
  description: string
}

interface CompanySettings {
  name: string
  address: string
  logoUrl?: string
  headerUrl?: string
}

export default function TimeKoApp() {
  const [currentUser, setCurrentUser] = useState<User | null>(null)
  const [activeTab, setActiveTab] = useState("dashboard")

  // Add new state for dashboard period selection
  const [dashboardPeriod, setDashboardPeriod] = useState("week")

  // Company settings state
  const [companySettings, setCompanySettings] = useState<CompanySettings>({
    name: "TimeKo",
    address: "123 Business Street, Makati City, Philippines",
    logoUrl: undefined,
    headerUrl: undefined,
  })

  // Sample data with Philippine context and pincodes
  const [employees, setEmployees] = useState<Employee[]>([
    {
      id: "1",
      name: "Maria Santos",
      email: "maria@example.com",
      hourlyRate: 75,
      position: "Crew",
      isActive: true,
      role: "employee",
      pincode: "1234",
    },
    {
      id: "2",
      name: "Juan Dela Cruz",
      email: "juan@example.com",
      hourlyRate: 85,
      position: "Asst Store Supv",
      isActive: true,
      role: "employee",
      pincode: "5678",
    },
    {
      id: "admin",
      name: "Admin User",
      email: "admin@example.com",
      hourlyRate: 150,
      position: "Store Supv",
      isActive: true,
      role: "admin",
      pincode: "0000",
    },
  ])

  const [schedules, setSchedules] = useState<Schedule[]>([
    {
      id: "1",
      employeeId: "1",
      date: "2024-01-15",
      startTime: "09:00",
      endTime: "18:00",
      dayType: "regular",
      isRestDay: false,
    },
    {
      id: "2",
      employeeId: "2",
      date: "2024-01-15",
      startTime: "08:00",
      endTime: "17:00",
      dayType: "regular",
      isRestDay: false,
    },
  ])

  const [timeEntries, setTimeEntries] = useState<TimeEntry[]>([
    {
      id: "1",
      employeeId: "1",
      date: "2024-01-15",
      clockIn: "09:15",
      clockOut: "18:30",
      hoursWorked: 8.25,
      isLate: true,
      lateMinutes: 15,
      lateReason: "Traffic jam on EDSA",
      isAbsent: false,
      status: "late",
      clockInComment: "Heavy traffic today",
      clockOutComment: "Completed all tasks",
    },
    {
      id: "2",
      employeeId: "2",
      date: "2024-01-15",
      clockIn: "07:55",
      clockOut: "17:00",
      hoursWorked: 8.0,
      isLate: false,
      lateMinutes: 0,
      isAbsent: false,
      status: "on-time",
    },
  ])

  const [cashAdvances, setCashAdvances] = useState<CashAdvance[]>([
    {
      id: "1",
      employeeId: "1",
      date: "2024-01-10",
      amount: 0,
      remarks: "Emergency expense",
      isPaid: false,
    },
  ])

  const [employeeDeductions, setEmployeeDeductions] = useState<EmployeeDeduction[]>([
    { id: "1", employeeId: "1", name: "SSS", type: "percentage", amount: 5, isActive: true },
    { id: "2", employeeId: "1", name: "PhilHealth", type: "percentage", amount: 2.5, isActive: true },
    { id: "3", employeeId: "1", name: "Pag-IBIG", type: "fixed", amount: 50, isActive: true },
    { id: "4", employeeId: "2", name: "SSS", type: "percentage", amount: 5, isActive: true },
    { id: "5", employeeId: "2", name: "PhilHealth", type: "percentage", amount: 2.5, isActive: true },
    { id: "6", employeeId: "2", name: "Pag-IBIG", type: "fixed", amount: 50, isActive: true },
  ])

  const [employeeAllowances, setEmployeeAllowances] = useState<EmployeeAllowance[]>([
    {
      id: "1",
      employeeId: "1",
      weekStartDate: "2024-01-15",
      amount: 0,
      description: "Allowance",
    },
    {
      id: "2",
      employeeId: "2",
      weekStartDate: "2024-01-15",
      amount: 0,
      description: "Allowance",
    },
  ])

  const todayEntries = timeEntries.filter((entry) => entry.date === new Date().toISOString().split("T")[0])
  const activeEmployees = employees.filter((emp) => emp.isActive && emp.role === "employee")
  const clockedInToday = todayEntries.filter((entry) => entry.clockIn && !entry.clockOut).length
  const totalHoursToday = todayEntries.reduce((sum, entry) => sum + entry.hoursWorked, 0)
  const lateEmployeesToday = todayEntries.filter((entry) => entry.isLate).length

  const handleLogin = (user: User) => {
    setCurrentUser(user)
    setActiveTab("dashboard")
  }

  const handleLogout = () => {
    setCurrentUser(null)
    setActiveTab("dashboard")
  }

  const generatePincode = () => {
    let pincode
    do {
      pincode = Math.floor(1000 + Math.random() * 9000).toString()
    } while (employees.some((emp) => emp.pincode === pincode))
    return pincode
  }

  const addEmployee = (employee: Omit<Employee, "id" | "pincode">) => {
    const newEmployee = {
      ...employee,
      id: Date.now().toString(),
      pincode: generatePincode(),
    }
    setEmployees([...employees, newEmployee])
  }

  const updateEmployee = (id: string, updates: Partial<Employee>) => {
    setEmployees(employees.map((emp) => (emp.id === id ? { ...emp, ...updates } : emp)))
  }

  const addTimeEntry = (entry: Omit<TimeEntry, "id">) => {
    const newEntry = {
      ...entry,
      id: Date.now().toString(),
    }
    setTimeEntries([...timeEntries, newEntry])
  }

  const updateTimeEntry = (id: string, updates: Partial<TimeEntry>) => {
    setTimeEntries(timeEntries.map((entry) => (entry.id === id ? { ...entry, ...updates } : entry)))
  }

  const addSchedule = (schedule: Omit<Schedule, "id">) => {
    const newSchedule = {
      ...schedule,
      id: Date.now().toString(),
    }
    setSchedules([...schedules, newSchedule])
  }

  const updateSchedule = (id: string, updates: Partial<Schedule>) => {
    setSchedules(schedules.map((schedule) => (schedule.id === id ? { ...schedule, ...updates } : schedule)))
  }

  const addCashAdvance = (advance: Omit<CashAdvance, "id">) => {
    const newAdvance = {
      ...advance,
      id: Date.now().toString(),
    }
    setCashAdvances([...cashAdvances, newAdvance])
  }

  const addEmployeeDeduction = (deduction: Omit<EmployeeDeduction, "id">) => {
    const newDeduction = {
      ...deduction,
      id: Date.now().toString(),
    }
    setEmployeeDeductions([...employeeDeductions, newDeduction])
  }

  const updateEmployeeDeduction = (id: string, updates: Partial<EmployeeDeduction>) => {
    setEmployeeDeductions(
      employeeDeductions.map((deduction) => (deduction.id === id ? { ...deduction, ...updates } : deduction)),
    )
  }

  const deleteEmployeeDeduction = (id: string) => {
    setEmployeeDeductions(employeeDeductions.filter((deduction) => deduction.id !== id))
  }

  const addEmployeeAllowance = (allowance: Omit<EmployeeAllowance, "id">) => {
    const newAllowance = {
      ...allowance,
      id: Date.now().toString(),
    }
    setEmployeeAllowances([...employeeAllowances, newAllowance])
  }

  const updateEmployeeAllowance = (id: string, updates: Partial<EmployeeAllowance>) => {
    setEmployeeAllowances(
      employeeAllowances.map((allowance) => (allowance.id === id ? { ...allowance, ...updates } : allowance)),
    )
  }

  const deleteEmployeeAllowance = (id: string) => {
    setEmployeeAllowances(employeeAllowances.filter((allowance) => allowance.id !== id))
  }

  const importSchedules = (scheduleData: any[]) => {
    const newSchedules = scheduleData.map((data) => ({
      id: Date.now().toString() + Math.random(),
      ...data,
    }))
    setSchedules([...schedules, ...newSchedules])
  }

  const importDeductions = (deductionData: any[]) => {
    const newDeductions = deductionData.map((data) => ({
      id: Date.now().toString() + Math.random(),
      ...data,
    }))
    setEmployeeDeductions([...employeeDeductions, ...newDeductions])
  }

  const updateCompanySettings = (settings: CompanySettings) => {
    setCompanySettings(settings)
  }

  // Add helper function to get date range for dashboard
  const getDashboardDateRange = () => {
    const today = new Date()
    const startDate = new Date()

    if (dashboardPeriod === "day") {
      startDate.setDate(today.getDate())
    } else if (dashboardPeriod === "week") {
      startDate.setDate(today.getDate() - 7)
    } else if (dashboardPeriod === "month") {
      startDate.setMonth(today.getMonth() - 1)
    }

    return { startDate, endDate: today }
  }

  // Add function to calculate attendance and punctuality rates
  const calculateAttendanceRates = () => {
    const { startDate, endDate } = getDashboardDateRange()

    const filteredEntries = timeEntries.filter((entry) => {
      const entryDate = new Date(entry.date)
      return entryDate >= startDate && entryDate <= endDate
    })

    const filteredSchedules = schedules.filter((schedule) => {
      const scheduleDate = new Date(schedule.date)
      return scheduleDate >= startDate && scheduleDate <= endDate
    })

    // Calculate team overall rates
    const totalScheduledDays = filteredSchedules.length
    const totalWorkedDays = filteredEntries.filter((entry) => entry.clockIn && entry.clockOut).length
    const totalLateDays = filteredEntries.filter((entry) => entry.isLate).length

    const teamAttendanceRate = totalScheduledDays > 0 ? (totalWorkedDays / totalScheduledDays) * 100 : 100
    const teamPunctualityRate = totalWorkedDays > 0 ? ((totalWorkedDays - totalLateDays) / totalWorkedDays) * 100 : 100

    // Calculate per employee rates
    const employeeRates = activeEmployees.map((employee) => {
      const employeeEntries = filteredEntries.filter((entry) => entry.employeeId === employee.id)
      const employeeSchedules = filteredSchedules.filter((schedule) => schedule.employeeId === employee.id)

      const scheduledDays = employeeSchedules.length
      const workedDays = employeeEntries.filter((entry) => entry.clockIn && entry.clockOut).length
      const lateDays = employeeEntries.filter((entry) => entry.isLate).length

      const attendanceRate = scheduledDays > 0 ? (workedDays / scheduledDays) * 100 : 100
      const punctualityRate = workedDays > 0 ? ((workedDays - lateDays) / workedDays) * 100 : 100

      return {
        employee,
        attendanceRate,
        punctualityRate,
        scheduledDays,
        workedDays,
        lateDays,
      }
    })

    return {
      teamAttendanceRate,
      teamPunctualityRate,
      employeeRates,
      totalScheduledDays,
      totalWorkedDays,
      totalLateDays,
    }
  }

  const attendanceData = calculateAttendanceRates()

  if (!currentUser) {
    return <LoginForm onLogin={handleLogin} employees={employees} />
  }

  const isAdmin = currentUser.role === "admin"
  const currentEmployee = employees.find((emp) => emp.id === currentUser.employeeId || emp.email === currentUser.email)

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Header */}
      <header className="bg-white shadow-sm border-b flex-shrink-0">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-3">
            <div className="flex items-center space-x-3">
              <div className="bg-blue-600 text-white p-2 rounded-lg">
                <Clock className="h-5 w-5" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">{companySettings.name}</h1>
                <p className="text-xs text-gray-500">Employee Time Tracker & Payroll (Philippines)</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="text-right">
                <p className="text-sm text-gray-500">Welcome, {currentUser.name}</p>
                <p className="text-xs text-gray-400">
                  {isAdmin ? "Administrator" : "Employee"} • {new Date().toLocaleDateString()}
                </p>
              </div>
              <Button variant="outline" size="sm" onClick={handleLogout}>
                <LogOut className="h-4 w-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className="bg-white shadow-sm flex-shrink-0">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex space-x-6 overflow-x-auto">
            {[
              { id: "dashboard", label: "Dashboard", icon: Calendar, adminOnly: false },
              { id: "time-tracking", label: "Time In/Out", icon: Clock, adminOnly: false },
              { id: "my-payroll", label: "My Payroll", icon: DollarSign, adminOnly: false, employeeOnly: true },
              { id: "schedule", label: "Schedule", icon: Calendar, adminOnly: false },
              { id: "employees", label: "Employees", icon: Users, adminOnly: true },
              { id: "deductions", label: "Deductions", icon: DollarSign, adminOnly: true },
              { id: "allowances", label: "Allowances", icon: DollarSign, adminOnly: true },
              { id: "attendance", label: "Attendance", icon: Calendar, adminOnly: true },
              { id: "payroll", label: "Payroll", icon: DollarSign, adminOnly: true },
              { id: "settings", label: "Settings", icon: Settings, adminOnly: true },
            ]
              .filter((item) => {
                if (item.adminOnly && !isAdmin) return false
                if (item.employeeOnly && isAdmin) return false
                return true
              })
              .map(({ id, label, icon: Icon }) => (
                <button
                  key={id}
                  onClick={() => setActiveTab(id)}
                  className={`flex items-center space-x-2 py-3 px-1 border-b-2 font-medium text-sm whitespace-nowrap ${
                    activeTab === id
                      ? "border-blue-500 text-blue-600"
                      : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  <span>{label}</span>
                </button>
              ))}
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 overflow-hidden">
        <div className="h-full overflow-y-auto">
          {activeTab === "dashboard" && (
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <div>
                  <h2 className="text-2xl font-bold text-gray-900">Dashboard</h2>
                  <p className="text-gray-600">
                    {isAdmin ? "Business overview and employee status" : "Your work summary"}
                  </p>
                </div>
                {isAdmin && (
                  <Select value={dashboardPeriod} onValueChange={setDashboardPeriod}>
                    <SelectTrigger className="w-32">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="day">Today</SelectItem>
                      <SelectItem value="week">Last Week</SelectItem>
                      <SelectItem value="month">Last Month</SelectItem>
                    </SelectContent>
                  </Select>
                )}
              </div>

              {/* Stats Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {isAdmin && (
                  <>
                    <Card>
                      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">Active Employees</CardTitle>
                        <Users className="h-4 w-4 text-muted-foreground" />
                      </CardHeader>
                      <CardContent>
                        <div className="text-xl font-bold">{activeEmployees.length}</div>
                        <p className="text-xs text-muted-foreground">Total staff members</p>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">Team Attendance</CardTitle>
                        <Calendar className="h-4 w-4 text-muted-foreground" />
                      </CardHeader>
                      <CardContent>
                        <div className="text-xl font-bold">{attendanceData.teamAttendanceRate.toFixed(1)}%</div>
                        <p className="text-xs text-muted-foreground">
                          {attendanceData.totalWorkedDays}/{attendanceData.totalScheduledDays} scheduled days
                        </p>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">Team Punctuality</CardTitle>
                        <Clock className="h-4 w-4 text-muted-foreground" />
                      </CardHeader>
                      <CardContent>
                        <div className="text-xl font-bold">{attendanceData.teamPunctualityRate.toFixed(1)}%</div>
                        <p className="text-xs text-muted-foreground">{attendanceData.totalLateDays} late arrivals</p>
                      </CardContent>
                    </Card>
                  </>
                )}

                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">
                      Hours {dashboardPeriod === "day" ? "Today" : `This ${dashboardPeriod}`}
                    </CardTitle>
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-xl font-bold">
                      {isAdmin
                        ? (() => {
                            const { startDate, endDate } = getDashboardDateRange()
                            const filteredEntries = timeEntries.filter((entry) => {
                              const entryDate = new Date(entry.date)
                              return entryDate >= startDate && entryDate <= endDate
                            })
                            return filteredEntries.reduce((sum, entry) => sum + entry.hoursWorked, 0).toFixed(1)
                          })()
                        : (() => {
                            const { startDate, endDate } = getDashboardDateRange()
                            const filteredEntries = timeEntries.filter((entry) => {
                              const entryDate = new Date(entry.date)
                              return (
                                entry.employeeId === currentEmployee?.id &&
                                entryDate >= startDate &&
                                entryDate <= endDate
                              )
                            })
                            return filteredEntries.reduce((sum, entry) => sum + entry.hoursWorked, 0).toFixed(1)
                          })()}
                    </div>
                    <p className="text-xs text-muted-foreground">{isAdmin ? "Total hours worked" : "Your hours"}</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Late Arrivals</CardTitle>
                    <Badge variant="destructive" className="h-4 w-4 p-0 flex items-center justify-center">
                      !
                    </Badge>
                  </CardHeader>
                  <CardContent>
                    <div className="text-xl font-bold">
                      {isAdmin
                        ? attendanceData.totalLateDays
                        : (() => {
                            const { startDate, endDate } = getDashboardDateRange()
                            const filteredEntries = timeEntries.filter((entry) => {
                              const entryDate = new Date(entry.date)
                              return (
                                entry.employeeId === currentEmployee?.id &&
                                entryDate >= startDate &&
                                entryDate <= endDate &&
                                entry.isLate
                              )
                            })
                            return filteredEntries.length
                          })()}
                    </div>
                    <p className="text-xs text-muted-foreground">{isAdmin ? "Team late arrivals" : "Your late days"}</p>
                  </CardContent>
                </Card>
              </div>

              {/* Employee Attendance Rates (Admin Only) */}
              {isAdmin && (
                <Card>
                  <CardHeader>
                    <CardTitle>Employee Attendance & Punctuality Rates</CardTitle>
                    <CardDescription>
                      Individual performance for the selected period ({dashboardPeriod})
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3 max-h-64 overflow-y-auto">
                      {attendanceData.employeeRates.map(
                        ({ employee, attendanceRate, punctualityRate, scheduledDays, workedDays, lateDays }) => (
                          <div key={employee.id} className="flex items-center justify-between p-3 border rounded-lg">
                            <div className="flex items-center space-x-3">
                              <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                                <span className="text-blue-600 font-semibold text-sm">
                                  {employee.name
                                    .split(" ")
                                    .map((n) => n[0])
                                    .join("")}
                                </span>
                              </div>
                              <div>
                                <h3 className="font-semibold text-sm">{employee.name}</h3>
                                <p className="text-xs text-gray-600">{employee.position}</p>
                              </div>
                            </div>
                            <div className="flex items-center space-x-4">
                              <div className="text-center">
                                <p className="text-xs text-gray-500">Attendance</p>
                                <div className="flex items-center space-x-2">
                                  <span className="font-semibold text-sm">{attendanceRate.toFixed(1)}%</span>
                                  <Badge
                                    variant={
                                      attendanceRate >= 95
                                        ? "default"
                                        : attendanceRate >= 85
                                          ? "secondary"
                                          : "destructive"
                                    }
                                    className="text-xs"
                                  >
                                    {workedDays}/{scheduledDays}
                                  </Badge>
                                </div>
                              </div>
                              <div className="text-center">
                                <p className="text-xs text-gray-500">Punctuality</p>
                                <div className="flex items-center space-x-2">
                                  <span className="font-semibold text-sm">{punctualityRate.toFixed(1)}%</span>
                                  <Badge
                                    variant={
                                      punctualityRate >= 90
                                        ? "default"
                                        : punctualityRate >= 75
                                          ? "secondary"
                                          : "destructive"
                                    }
                                    className="text-xs"
                                  >
                                    {lateDays} late
                                  </Badge>
                                </div>
                              </div>
                            </div>
                          </div>
                        ),
                      )}
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Recent Activity */}
              <Card>
                <CardHeader>
                  <CardTitle>{isAdmin ? "Recent Activity" : "Your Recent Activity"}</CardTitle>
                  <CardDescription>Recent clock-ins and clock-outs</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 max-h-64 overflow-y-auto">
                    {(() => {
                      const { startDate, endDate } = getDashboardDateRange()
                      const filteredEntries = timeEntries.filter((entry) => {
                        const entryDate = new Date(entry.date)
                        return (
                          entryDate >= startDate &&
                          entryDate <= endDate &&
                          (isAdmin || entry.employeeId === currentEmployee?.id)
                        )
                      })

                      return filteredEntries.length === 0 ? (
                        <p className="text-gray-500 text-center py-4">No activity recorded for this period</p>
                      ) : (
                        filteredEntries
                          .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                          .slice(0, 10)
                          .map((entry) => {
                            const employee = employees.find((emp) => emp.id === entry.employeeId)
                            return (
                              <div
                                key={entry.id}
                                className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
                              >
                                <div className="flex items-center space-x-3">
                                  <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                                    <span className="text-blue-600 font-semibold text-sm">
                                      {employee?.name
                                        .split(" ")
                                        .map((n) => n[0])
                                        .join("")}
                                    </span>
                                  </div>
                                  <div>
                                    <p className="font-medium text-sm">{employee?.name}</p>
                                    <p className="text-xs text-gray-500">{new Date(entry.date).toLocaleDateString()}</p>
                                    {entry.clockInComment && (
                                      <p className="text-xs text-blue-600">Comment: {entry.clockInComment}</p>
                                    )}
                                  </div>
                                </div>
                                <div className="text-right">
                                  <div className="flex items-center space-x-2">
                                    <span className="text-sm">
                                      {entry.clockIn || "Not clocked in"} - {entry.clockOut || "Working"}
                                    </span>
                                    {entry.isLate && (
                                      <Badge variant="destructive" className="text-xs">
                                        Late {entry.lateMinutes}min
                                      </Badge>
                                    )}
                                    {entry.adminOverride && (
                                      <Badge variant="outline" className="text-xs">
                                        Admin Override
                                      </Badge>
                                    )}
                                  </div>
                                  <p className="text-xs text-gray-500">
                                    {entry.hoursWorked.toFixed(1)} hours • ₱
                                    {(entry.hoursWorked * (employee?.hourlyRate || 0)).toFixed(2)}
                                  </p>
                                </div>
                              </div>
                            )
                          })
                      )
                    })()}
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {activeTab === "time-tracking" && (
            <TimeTracking
              currentUser={currentUser}
              employees={employees}
              schedules={schedules}
              timeEntries={timeEntries}
              onAddTimeEntry={addTimeEntry}
              onUpdateTimeEntry={updateTimeEntry}
            />
          )}

          {activeTab === "schedule" && (
            <ScheduleManagement
              currentUser={currentUser}
              employees={employees}
              schedules={schedules}
              companySettings={companySettings}
              onAddSchedule={addSchedule}
              onUpdateSchedule={updateSchedule}
              onImportSchedules={importSchedules}
            />
          )}

          {isAdmin && activeTab === "employees" && (
            <EmployeeManagement employees={employees} onAddEmployee={addEmployee} onUpdateEmployee={updateEmployee} />
          )}

          {isAdmin && activeTab === "deductions" && (
            <DeductionManagement
              employees={employees}
              employeeDeductions={employeeDeductions}
              onAddDeduction={addEmployeeDeduction}
              onUpdateDeduction={updateEmployeeDeduction}
              onDeleteDeduction={deleteEmployeeDeduction}
              onImportDeductions={importDeductions}
            />
          )}

          {isAdmin && activeTab === "allowances" && (
            <AllowanceManagement
              employees={employees}
              employeeAllowances={employeeAllowances}
              onAddAllowance={addEmployeeAllowance}
              onUpdateAllowance={updateEmployeeAllowance}
              onDeleteAllowance={deleteEmployeeAllowance}
            />
          )}

          {isAdmin && activeTab === "attendance" && (
            <AttendanceOverview employees={employees} timeEntries={timeEntries} schedules={schedules} />
          )}

          {isAdmin && activeTab === "payroll" && (
            <PayrollGenerator
              employees={employees}
              timeEntries={timeEntries}
              cashAdvances={cashAdvances}
              deductions={employeeDeductions}
              employeeAllowances={employeeAllowances}
              schedules={schedules}
              onAddCashAdvance={addCashAdvance}
            />
          )}

          {isAdmin && activeTab === "settings" && (
            <SettingsComponent settings={companySettings} onUpdateSettings={updateCompanySettings} />
          )}

          {activeTab === "my-payroll" && !isAdmin && (
            <EmployeePayrollView
              currentUser={currentUser}
              employees={employees}
              timeEntries={timeEntries}
              schedules={schedules}
              cashAdvances={cashAdvances}
              employeeDeductions={employeeDeductions}
              employeeAllowances={employeeAllowances}
              companySettings={companySettings}
            />
          )}
        </div>
      </main>
    </div>
  )
}
