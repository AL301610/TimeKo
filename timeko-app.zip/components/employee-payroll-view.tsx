"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { Calendar, Clock, DollarSign, FileText, Download } from "lucide-react"
import { Label } from "@/components/ui/label"

interface User {
  id: string
  name: string
  role: "admin" | "employee"
  employeeId?: string
}

interface Employee {
  id: string
  name: string
  hourlyRate: number
  position: string
  role: "admin" | "employee"
}

interface TimeEntry {
  id: string
  employeeId: string
  date: string
  clockIn?: string
  clockOut?: string
  hoursWorked: number
  isLate: boolean
  lateMinutes: number
  isAbsent: boolean
  status: "on-time" | "late" | "absent"
}

interface Schedule {
  id: string
  employeeId: string
  date: string
  startTime: string
  endTime: string
  dayType: "regular" | "sunday" | "holiday"
  isRestDay: boolean
}

interface CashAdvance {
  id: string
  employeeId: string
  date: string
  amount: number
  remarks: string
  isPaid: boolean
}

interface EmployeeDeduction {
  id: string
  employeeId: string
  name: string
  type: "fixed" | "percentage"
  amount: number
  isActive: boolean
}

interface EmployeeAllowance {
  id: string
  employeeId: string
  weekStartDate: string
  amount: number
  description: string
}

interface CompanySettings {
  name: string
  address: string
  logoUrl?: string
  headerUrl?: string
}

interface EmployeePayrollViewProps {
  currentUser: User
  employees: Employee[]
  timeEntries: TimeEntry[]
  schedules: Schedule[]
  cashAdvances: CashAdvance[]
  employeeDeductions: EmployeeDeduction[]
  employeeAllowances?: EmployeeAllowance[]
  companySettings: CompanySettings
}

interface DailyPayData {
  date: string
  dayName: string
  clockIn?: string
  clockOut?: string
  hoursWorked: number
  regularHours: number
  overtimeHours: number
  isSundayHoliday: boolean
  regularPay: number
  overtimePay: number
  sundayHolidayPay: number
  totalDayPay: number
  status: "on-time" | "late" | "absent" | "rest-day"
  isLate: boolean
  lateMinutes: number
}

export function EmployeePayrollView({
  currentUser,
  employees,
  timeEntries,
  schedules,
  cashAdvances,
  employeeDeductions,
  employeeAllowances = [],
  companySettings,
}: EmployeePayrollViewProps) {
  const [selectedWeek, setSelectedWeek] = useState(getWeekStart(new Date()))

  const currentEmployee = employees.find((emp) => emp.id === currentUser.employeeId || emp.email === currentUser.email)

  function getWeekStart(date: Date) {
    const d = new Date(date)
    const day = d.getDay()
    const diff = d.getDate() - day + (day === 0 ? -6 : 1) // Start from Monday
    return new Date(d.setDate(diff)).toISOString().split("T")[0]
  }

  function getWeekDates(weekStart: string) {
    const dates = []
    const start = new Date(weekStart)
    for (let i = 0; i < 7; i++) {
      const date = new Date(start)
      date.setDate(start.getDate() + i)
      dates.push(date.toISOString().split("T")[0])
    }
    return dates
  }

  const weekDates = getWeekDates(selectedWeek)
  const dayNames = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]

  const calculateDailyPay = (date: string): DailyPayData => {
    const dayIndex = weekDates.indexOf(date)
    const dayName = dayNames[dayIndex]

    const timeEntry = timeEntries.find((entry) => entry.employeeId === currentEmployee?.id && entry.date === date)

    const schedule = schedules.find((schedule) => schedule.employeeId === currentEmployee?.id && schedule.date === date)

    if (!timeEntry || !timeEntry.clockIn || !timeEntry.clockOut) {
      return {
        date,
        dayName,
        hoursWorked: 0,
        regularHours: 0,
        overtimeHours: 0,
        isSundayHoliday: false,
        regularPay: 0,
        overtimePay: 0,
        sundayHolidayPay: 0,
        totalDayPay: 0,
        status: schedule ? (timeEntry ? "absent" : "rest-day") : "rest-day",
        isLate: false,
        lateMinutes: 0,
      }
    }

    const entryDate = new Date(date)
    const dayOfWeek = entryDate.getDay() // 0 = Sunday, 6 = Saturday
    const isSunday = dayOfWeek === 0
    const isHoliday = schedule?.dayType === "holiday"
    const isSundayHoliday = isSunday || isHoliday

    let regularHours = 0
    let overtimeHours = 0
    let sundayHolidayHours = 0

    if (isSundayHoliday) {
      // Sunday/Holiday work = 125% rate for all hours
      sundayHolidayHours = timeEntry.hoursWorked
    } else {
      // Regular day: first 9 hours = regular, beyond 9 hours = overtime
      if (timeEntry.hoursWorked <= 9) {
        regularHours = timeEntry.hoursWorked
      } else {
        regularHours = 9
        overtimeHours = timeEntry.hoursWorked - 9
      }
    }

    const hourlyRate = currentEmployee?.hourlyRate || 0
    const regularPay = regularHours * hourlyRate
    const overtimePay = overtimeHours * hourlyRate * 1.25
    const sundayHolidayPay = sundayHolidayHours * hourlyRate * 1.25

    return {
      date,
      dayName,
      clockIn: timeEntry.clockIn,
      clockOut: timeEntry.clockOut,
      hoursWorked: timeEntry.hoursWorked,
      regularHours,
      overtimeHours,
      isSundayHoliday,
      regularPay,
      overtimePay,
      sundayHolidayPay,
      totalDayPay: regularPay + overtimePay + sundayHolidayPay,
      status: timeEntry.status,
      isLate: timeEntry.isLate,
      lateMinutes: timeEntry.lateMinutes,
    }
  }

  const weeklyData = weekDates.map(calculateDailyPay)

  // Calculate weekly totals
  const weeklyTotals = {
    totalHours: weeklyData.reduce((sum, day) => sum + day.hoursWorked, 0),
    totalRegularHours: weeklyData.reduce((sum, day) => sum + day.regularHours, 0),
    totalOvertimeHours: weeklyData.reduce((sum, day) => sum + day.overtimeHours, 0),
    totalSundayHolidayHours: weeklyData.reduce((sum, day) => sum + (day.isSundayHoliday ? day.hoursWorked : 0), 0),
    totalRegularPay: weeklyData.reduce((sum, day) => sum + day.regularPay, 0),
    totalOvertimePay: weeklyData.reduce((sum, day) => sum + day.overtimePay, 0),
    totalSundayHolidayPay: weeklyData.reduce((sum, day) => sum + day.sundayHolidayPay, 0),
    grossPay: weeklyData.reduce((sum, day) => sum + day.totalDayPay, 0),
  }

  // Calculate deductions based on basic pay (regular hours × hourly rate)
  const basicPay = weeklyTotals.totalRegularHours * (currentEmployee?.hourlyRate || 0)

  // Only apply deductions on the last day of the week (Sunday)
  const isLastDayOfWeek = (date: string) => {
    const dayIndex = weekDates.indexOf(date)
    return dayIndex === 6 // Sunday is the last day (index 6)
  }

  // Check if we have any Sunday entries in the week to apply Pag-IBIG
  const hasEndOfWeekEntry = weeklyData.some((day) => {
    const dayIndex = weekDates.indexOf(day.date)
    return dayIndex === 6 && day.hoursWorked > 0 // Sunday with actual work
  })

  // Standard deductions based on Philippine labor standards - only on last day
  const standardDeductions = [
    { name: "SSS", amount: basicPay * 0.05 }, // 5% of basic pay
    { name: "PhilHealth", amount: basicPay * 0.025 }, // 2.5% of basic pay
    { name: "Pag-IBIG", amount: hasEndOfWeekEntry ? 50 : 0 }, // ₱50 only if worked on Sunday (end of week)
  ].filter((deduction) => deduction.amount > 0) // Remove zero amounts

  // Add custom employee deductions if any (exclude standard ones to avoid duplication)
  const customDeductions = employeeDeductions
    .filter(
      (deduction) =>
        deduction.employeeId === currentEmployee?.id &&
        deduction.isActive &&
        !["SSS", "PhilHealth", "Pag-IBIG"].includes(deduction.name), // Exclude standard deductions
    )
    .map((deduction) => ({
      name: deduction.name,
      amount: deduction.type === "fixed" ? deduction.amount : (basicPay * deduction.amount) / 100,
    }))

  const allDeductions = [...standardDeductions, ...customDeductions]

  const totalDeductions = allDeductions.reduce((sum, deduction) => sum + deduction.amount, 0)

  // Calculate cash advances
  const weekStart = new Date(selectedWeek)
  const weekEnd = new Date(weekStart)
  weekEnd.setDate(weekStart.getDate() + 6)

  const employeeCashAdvances = cashAdvances
    .filter((advance) => {
      const advanceDate = new Date(advance.date)
      return (
        advance.employeeId === currentEmployee?.id &&
        !advance.isPaid &&
        advanceDate >= weekStart &&
        advanceDate <= weekEnd
      )
    })
    .reduce((sum, advance) => sum + advance.amount, 0)

  // Calculate allowances for the week
  const employeeAllowancesForWeek = employeeAllowances
    .filter((allowance) => {
      const allowanceWeekStart = new Date(allowance.weekStartDate)
      return (
        allowance.employeeId === currentEmployee?.id && allowanceWeekStart >= weekStart && allowanceWeekStart <= weekEnd
      )
    })
    .reduce((sum, allowance) => sum + allowance.amount, 0)

  // Calculate late penalties
  const lateCount = weeklyData.filter((day) => day.isLate).length
  const latePenalty = lateCount * 50 // ₱50 per late day

  const netPay =
    weeklyTotals.grossPay - totalDeductions - employeeCashAdvances - latePenalty + employeeAllowancesForWeek

  if (!currentEmployee) {
    return <div>Employee not found</div>
  }

  interface EmployeeData {
    totalDeductions: number
    cashAdvances: number
    latePenalty: number
  }

  const employeeData: EmployeeData = {
    totalDeductions: totalDeductions || 0,
    cashAdvances: employeeCashAdvances || 0,
    latePenalty: latePenalty || 0,
  }

  // Function to generate and download PDF payslip
  const generatePDF = () => {
    // Create a hidden iframe to render the PDF content
    const iframe = document.createElement("iframe")
    iframe.style.display = "none"
    document.body.appendChild(iframe)

    // Generate the HTML content for the PDF with smaller fonts
    const html = `
    <!DOCTYPE html>
    <html>
    <head>
      <title>Payslip - ${currentEmployee.name}</title>
      <style>
        body {
          font-family: Arial, sans-serif;
          margin: 10px;
          padding: 0;
          color: #333;
          font-size: 10px;
          line-height: 1.2;
        }
        .header {
          text-align: center;
          margin-bottom: 10px;
          border-bottom: 1px solid #333;
          padding-bottom: 5px;
        }
        .company-name {
          font-size: 16px;
          font-weight: bold;
          margin: 0;
        }
        .company-address {
          font-size: 10px;
          margin: 2px 0;
          color: #666;
        }
        .payslip-title {
          font-size: 12px;
          margin: 2px 0;
        }
        .period {
          font-size: 10px;
          margin: 2px 0;
        }
        .employee-info {
          margin-bottom: 10px;
        }
        .employee-info table {
          width: 100%;
          border-collapse: collapse;
          font-size: 9px;
        }
        .employee-info td {
          padding: 2px;
        }
        .section {
          margin-bottom: 8px;
        }
        .section-title {
          font-weight: bold;
          font-size: 10px;
          border-bottom: 1px solid #ccc;
          padding-bottom: 2px;
          margin-bottom: 5px;
        }
        table.data {
          width: 100%;
          border-collapse: collapse;
          font-size: 8px;
        }
        table.data th, table.data td {
          border: 1px solid #ccc;
          padding: 3px;
          text-align: left;
        }
        table.data th {
          background-color: #f2f2f2;
          font-size: 8px;
        }
        .summary {
          margin-top: 10px;
          border-top: 1px solid #ccc;
          padding-top: 5px;
        }
        .summary table {
          width: 100%;
          font-size: 9px;
        }
        .summary td {
          padding: 2px;
        }
        .total {
          font-weight: bold;
        }
        .footer {
          margin-top: 15px;
          text-align: center;
          font-size: 8px;
          color: #666;
        }
        .two-column {
          display: flex;
          gap: 10px;
        }
        .column {
          flex: 1;
        }
      </style>
    </head>
    <body>
      <div class="header">
        <p class="company-name">${companySettings.name || "TimeKo"}</p>
        ${companySettings.address ? `<p class="company-address">${companySettings.address}</p>` : ""}
        <p class="payslip-title">EMPLOYEE PAYSLIP</p>
        <p class="period">Pay Period: ${weekStart.toLocaleDateString()} - ${weekEnd.toLocaleDateString()}</p>
      </div>
      
      <div class="employee-info">
        <table>
          <tr>
            <td width="50%"><strong>Employee:</strong> ${currentEmployee.name}</td>
            <td width="50%"><strong>Position:</strong> ${currentEmployee.position}</td>
          </tr>
          <tr>
            <td><strong>ID:</strong> ${currentEmployee.id}</td>
            <td><strong>Rate:</strong> ₱${currentEmployee.hourlyRate.toFixed(2)}/hr</td>
          </tr>
        </table>
      </div>
      
      <div class="two-column">
        <div class="column">
          <div class="section">
            <div class="section-title">ATTENDANCE SUMMARY</div>
            <table class="data">
              <thead>
                <tr>
                  <th>Date</th>
                  <th>In</th>
                  <th>Out</th>
                  <th>Hrs</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                ${weeklyData
                  .map(
                    (day) => `
                  <tr>
                    <td>${new Date(day.date).toLocaleDateString("en-US", { month: "2-digit", day: "2-digit" })}</td>
                    <td>${day.clockIn || "-"}</td>
                    <td>${day.clockOut || "-"}</td>
                    <td>${day.hoursWorked > 0 ? day.hoursWorked.toFixed(1) : "-"}</td>
                    <td>${day.status}</td>
                  </tr>
                `,
                  )
                  .join("")}
              </tbody>
            </table>
          </div>
        </div>
        
        <div class="column">
          <div class="section">
            <div class="section-title">EARNINGS</div>
            <table class="data">
              <thead>
                <tr>
                  <th>Type</th>
                  <th>Hrs</th>
                  <th>Rate</th>
                  <th>Amount</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>Regular</td>
                  <td>${weeklyTotals.totalRegularHours.toFixed(1)}</td>
                  <td>₱${currentEmployee.hourlyRate.toFixed(0)}</td>
                  <td>₱${weeklyTotals.totalRegularPay.toFixed(2)}</td>
                </tr>
                ${
                  weeklyTotals.totalOvertimeHours > 0
                    ? `
                  <tr>
                    <td>Overtime</td>
                    <td>${weeklyTotals.totalOvertimeHours.toFixed(1)}</td>
                    <td>₱${(currentEmployee.hourlyRate * 1.25).toFixed(0)}</td>
                    <td>₱${weeklyTotals.totalOvertimePay.toFixed(2)}</td>
                  </tr>
                `
                    : ""
                }
                ${
                  weeklyTotals.totalSundayHolidayHours > 0
                    ? `
                  <tr>
                    <td>Holiday</td>
                    <td>${weeklyTotals.totalSundayHolidayHours.toFixed(1)}</td>
                    <td>₱${(currentEmployee.hourlyRate * 1.25).toFixed(0)}</td>
                    <td>₱${weeklyTotals.totalSundayHolidayPay.toFixed(2)}</td>
                  </tr>
                `
                    : ""
                }
                ${
                  employeeAllowancesForWeek > 0
                    ? `
                  <tr>
                    <td>Allowances</td>
                    <td>-</td>
                    <td>-</td>
                    <td>₱${employeeAllowancesForWeek.toFixed(2)}</td>
                  </tr>
                `
                    : ""
                }
                <tr>
                  <td colspan="3" class="total">Gross Pay</td>
                  <td class="total">₱${weeklyTotals.grossPay.toFixed(2)}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
      
      <div class="section">
        <div class="section-title">DEDUCTIONS & CASH ADVANCES (Applied on last day of week):</div>
        <table class="data">
          <thead>
            <tr>
              <th>Description</th>
              <th>Amount</th>
            </tr>
          </thead>
          <tbody>
            ${allDeductions
              .map(
                (deduction) => `
              <tr>
                <td>${deduction.name}</td>
                <td>₱${deduction.amount.toFixed(2)}</td>
              </tr>
            `,
              )
              .join("")}
            ${
              employeeCashAdvances > 0
                ? `
              <tr>
                <td>Cash Advance</td>
                <td>₱${employeeCashAdvances.toFixed(2)}</td>
              </tr>
            `
                : ""
            }
            ${
              latePenalty > 0
                ? `
              <tr>
                <td>Late Penalty (${lateCount} days)</td>
                <td>₱${latePenalty.toFixed(2)}</td>
              </tr>
            `
                : ""
            }
            <tr>
              <td class="total">Total Deductions</td>
              <td class="total">₱${(totalDeductions + employeeCashAdvances + latePenalty).toFixed(2)}</td>
            </tr>
          </tbody>
        </table>
      </div>
      
      <div class="summary">
        <table>
          <tr>
            <td width="70%"><strong>Gross Pay:</strong></td>
            <td width="30%">₱${weeklyTotals.grossPay.toFixed(2)}</td>
          </tr>
          <tr>
            <td><strong>TOTAL DEDUCTIONS & ADVANCES:</strong></td>
            <td>₱${(employeeData.totalDeductions + employeeData.cashAdvances + employeeData.latePenalty).toFixed(2)}</td>
          </tr>
          <tr style="font-size: 12px;">
            <td><strong>NET PAY:</strong></td>
            <td><strong>₱${netPay.toFixed(2)}</strong></td>
          </tr>
        </table>
      </div>
      
      <div class="footer">
        <p>Computer-generated document. No signature required.</p>
        <p>Generated: ${new Date().toLocaleString()}</p>
      </div>
    </body>
    </html>
  `

    // Write the HTML to the iframe
    iframe.contentWindow.document.open()
    iframe.contentWindow.document.write(html)
    iframe.contentWindow.document.close()

    // Print the iframe content to PDF
    setTimeout(() => {
      iframe.contentWindow.print()
      // Remove the iframe after printing
      setTimeout(() => {
        document.body.removeChild(iframe)
      }, 1000)
    }, 500)
  }

  return (
    <div className="space-y-4 max-h-screen overflow-y-auto">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">My Payroll & Attendance</h2>
          <p className="text-gray-600">Your weekly timesheet and pay breakdown</p>
        </div>
        <div className="flex items-center space-x-4">
          <div className="flex flex-col">
            <Label htmlFor="weekStart" className="text-sm text-gray-600 mb-1">
              Select first day of week (Monday):
            </Label>
            <input
              id="weekStart"
              type="date"
              value={selectedWeek}
              onChange={(e) => setSelectedWeek(getWeekStart(new Date(e.target.value)))}
              className="px-3 py-2 border border-gray-300 rounded-md"
            />
          </div>
          <Button onClick={generatePDF} variant="outline" className="flex items-center gap-2 mt-6">
            <Download className="h-4 w-4" />
            <span>Export PDF</span>
          </Button>
        </div>
      </div>

      {/* Employee Info */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
              <span className="text-blue-600 font-semibold text-sm">
                {currentEmployee.name
                  .split(" ")
                  .map((n) => n[0])
                  .join("")}
              </span>
            </div>
            <div>
              <span className="text-lg">{currentEmployee.name}</span>
              <p className="text-sm text-gray-500 font-normal">
                {currentEmployee.position} • ₱{currentEmployee.hourlyRate}/hour
              </p>
            </div>
          </CardTitle>
          <CardDescription>
            Week of {new Date(selectedWeek).toLocaleDateString()} - {new Date(weekDates[6]).toLocaleDateString()}
          </CardDescription>
        </CardHeader>
      </Card>

      {/* Weekly Summary */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Hours</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-xl font-bold">{weeklyTotals.totalHours.toFixed(1)}</div>
            <p className="text-xs text-muted-foreground">
              Regular: {weeklyTotals.totalRegularHours.toFixed(1)}h | OT: {weeklyTotals.totalOvertimeHours.toFixed(1)}h
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Gross Pay</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-xl font-bold text-green-600">₱{weeklyTotals.grossPay.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">Before deductions</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Deductions</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-xl font-bold text-red-600">
              ₱{(totalDeductions + employeeCashAdvances + latePenalty).toFixed(2)}
            </div>
            <p className="text-xs text-muted-foreground">Applied on Sunday</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Net Pay</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-xl font-bold text-blue-600">₱{netPay.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">Take home pay</p>
          </CardContent>
        </Card>
      </div>

      {/* Daily Attendance Table */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center space-x-2 text-lg">
            <Calendar className="h-5 w-5" />
            <span>Daily Attendance & Pay</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full border-collapse text-sm">
              <thead>
                <tr className="border-b">
                  <th className="text-left p-2">Day</th>
                  <th className="text-center p-2">Time In</th>
                  <th className="text-center p-2">Time Out</th>
                  <th className="text-center p-2">Hours</th>
                  <th className="text-center p-2">Regular Pay</th>
                  <th className="text-center p-2">OT/Holiday Pay</th>
                  <th className="text-center p-2">Total Pay</th>
                  <th className="text-center p-2">Status</th>
                </tr>
              </thead>
              <tbody>
                {weeklyData.map((day) => (
                  <tr key={day.date} className="border-b hover:bg-gray-50">
                    <td className="p-2">
                      <div>
                        <div className="font-medium">{day.dayName}</div>
                        <div className="text-xs text-gray-500">{new Date(day.date).toLocaleDateString()}</div>
                      </div>
                    </td>
                    <td className="text-center p-2">
                      {day.clockIn || "-"}
                      {day.isLate && <div className="text-xs text-red-600">Late {day.lateMinutes}min</div>}
                    </td>
                    <td className="text-center p-2">{day.clockOut || "-"}</td>
                    <td className="text-center p-2">
                      {day.hoursWorked > 0 ? (
                        <div>
                          <div className="font-medium">{day.hoursWorked.toFixed(1)}h</div>
                          {day.overtimeHours > 0 && (
                            <div className="text-xs text-orange-600">OT: {day.overtimeHours.toFixed(1)}h</div>
                          )}
                          {day.isSundayHoliday && <div className="text-xs text-purple-600">Holiday/Sunday</div>}
                        </div>
                      ) : (
                        "-"
                      )}
                    </td>
                    <td className="text-center p-2">{day.regularPay > 0 ? `₱${day.regularPay.toFixed(2)}` : "-"}</td>
                    <td className="text-center p-2">
                      {day.overtimePay + day.sundayHolidayPay > 0
                        ? `₱${(day.overtimePay + day.sundayHolidayPay).toFixed(2)}`
                        : "-"}
                    </td>
                    <td className="text-center p-2 font-semibold">
                      {day.totalDayPay > 0 ? `₱${day.totalDayPay.toFixed(2)}` : "-"}
                    </td>
                    <td className="text-center p-2">
                      <Badge
                        variant={
                          day.status === "on-time"
                            ? "default"
                            : day.status === "late"
                              ? "destructive"
                              : day.status === "absent"
                                ? "destructive"
                                : "secondary"
                        }
                        className="text-xs"
                      >
                        {day.status === "rest-day" ? "Rest" : day.status}
                      </Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Detailed Pay Breakdown */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center space-x-2 text-lg">
            <FileText className="h-5 w-5" />
            <span>Pay Breakdown</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {/* Basic Pay Info */}
            <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
              <h4 className="font-semibold text-blue-800 mb-1">Basic Pay Calculation</h4>
              <p className="text-sm text-blue-700">
                Basic Pay = Regular Hours × Hourly Rate = {weeklyTotals.totalRegularHours.toFixed(1)}h × ₱
                {currentEmployee.hourlyRate} = ₱{basicPay.toFixed(2)}
              </p>
              <p className="text-xs text-blue-600 mt-1">
                *Basic pay is used for calculating SSS and PhilHealth deductions (applied on Sunday)
              </p>
            </div>

            {/* Earnings */}
            <div>
              <h4 className="font-semibold mb-2 text-green-700">EARNINGS</h4>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span>
                    Regular Hours ({weeklyTotals.totalRegularHours.toFixed(1)}h @ ₱{currentEmployee.hourlyRate}/hr)
                  </span>
                  <span>₱{weeklyTotals.totalRegularPay.toFixed(2)}</span>
                </div>
                {weeklyTotals.totalOvertimeHours > 0 && (
                  <div className="flex justify-between">
                    <span>
                      Overtime Hours ({weeklyTotals.totalOvertimeHours.toFixed(1)}h @ ₱
                      {(currentEmployee.hourlyRate * 1.25).toFixed(2)}/hr)
                    </span>
                    <span>₱{weeklyTotals.totalOvertimePay.toFixed(2)}</span>
                  </div>
                )}
                {weeklyTotals.totalSundayHolidayHours > 0 && (
                  <div className="flex justify-between">
                    <span>
                      Sunday/Holiday Hours ({weeklyTotals.totalSundayHolidayHours.toFixed(1)}h @ ₱
                      {(currentEmployee.hourlyRate * 1.25).toFixed(2)}/hr)
                    </span>
                    <span>₱{weeklyTotals.totalSundayHolidayPay.toFixed(2)}</span>
                  </div>
                )}
                {employeeAllowancesForWeek > 0 && (
                  <div className="flex justify-between">
                    <span>Allowances</span>
                    <span>₱{employeeAllowancesForWeek.toFixed(2)}</span>
                  </div>
                )}
              </div>
              <Separator className="my-2" />
              <div className="flex justify-between font-semibold">
                <span>Gross Pay:</span>
                <span>₱{weeklyTotals.grossPay.toFixed(2)}</span>
              </div>
            </div>

            <Separator />

            {/* Deductions */}
            <div>
              <h4 className="font-semibold mb-2 text-red-700">DEDUCTIONS & CASH ADVANCES (Applied on Sunday)</h4>
              <div className="space-y-2 text-sm">
                {allDeductions.map((deduction) => (
                  <div key={deduction.name} className="flex justify-between">
                    <span>
                      - {deduction.name}
                      {deduction.name === "SSS" && ` (5% of basic pay)`}
                      {deduction.name === "PhilHealth" && ` (2.5% of basic pay)`}
                      {deduction.name === "Pag-IBIG" && ` (₱50/week)`}
                    </span>
                    <span className="text-red-600">₱{deduction.amount.toFixed(2)}</span>
                  </div>
                ))}
                {employeeCashAdvances > 0 && (
                  <div className="flex justify-between">
                    <span>- Cash Advance</span>
                    <span className="text-red-600">₱{employeeCashAdvances.toFixed(2)}</span>
                  </div>
                )}
                {latePenalty > 0 && (
                  <div className="flex justify-between">
                    <span>- Late Penalty ({lateCount} days)</span>
                    <span className="text-red-600">₱{latePenalty.toFixed(2)}</span>
                  </div>
                )}
              </div>
              <Separator className="my-2" />
              <div className="flex justify-between font-semibold">
                <span>Total Deductions:</span>
                <span className="text-red-600">
                  ₱{(totalDeductions + employeeCashAdvances + latePenalty).toFixed(2)}
                </span>
              </div>
            </div>

            <Separator />

            {/* Net Pay */}
            <div className="flex justify-between text-lg font-bold">
              <span>NET PAY:</span>
              <span className="text-blue-600">₱{netPay.toFixed(2)}</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
