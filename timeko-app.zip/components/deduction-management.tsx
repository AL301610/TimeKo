"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Plus, Edit, Trash2, Upload, Download, DollarSign } from "lucide-react"

interface Employee {
  id: string
  name: string
  position: string
  role: "admin" | "employee"
}

interface EmployeeDeduction {
  id: string
  employeeId: string
  name: string
  type: "fixed" | "percentage"
  amount: number
  isActive: boolean
  cashAdvanceAmount?: number
  cashAdvanceSchedule?: "weekly" | "biweekly" | "monthly"
}

interface DeductionManagementProps {
  employees: Employee[]
  employeeDeductions: EmployeeDeduction[]
  onAddDeduction: (deduction: Omit<EmployeeDeduction, "id">) => void
  onUpdateDeduction: (id: string, updates: Partial<EmployeeDeduction>) => void
  onDeleteDeduction: (id: string) => void
  onImportDeductions: (deductions: any[]) => void
}

export function DeductionManagement({
  employees,
  employeeDeductions,
  onAddDeduction,
  onUpdateDeduction,
  onDeleteDeduction,
  onImportDeductions,
}: DeductionManagementProps) {
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [editingDeduction, setEditingDeduction] = useState<EmployeeDeduction | null>(null)
  const [selectedEmployee, setSelectedEmployee] = useState("all")
  const [formData, setFormData] = useState({
    employeeId: "",
    name: "",
    type: "fixed" as "fixed" | "percentage",
    amount: "",
    cashAdvanceAmount: "0", // Add this
    cashAdvanceSchedule: "weekly" as "weekly" | "biweekly" | "monthly", // Add this
  })

  const activeEmployees = employees.filter((emp) => emp.role === "employee")

  const filteredDeductions = employeeDeductions.filter(
    (deduction) => selectedEmployee === "all" || deduction.employeeId === selectedEmployee,
  )

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (editingDeduction) {
      onUpdateDeduction(editingDeduction.id, {
        employeeId: formData.employeeId,
        name: formData.name,
        type: formData.type,
        amount: Number.parseFloat(formData.amount),
        cashAdvanceAmount: Number.parseFloat(formData.cashAdvanceAmount),
        cashAdvanceSchedule: formData.cashAdvanceSchedule,
      })
      setEditingDeduction(null)
    } else {
      onAddDeduction({
        employeeId: formData.employeeId,
        name: formData.name,
        type: formData.type,
        amount: Number.parseFloat(formData.amount),
        cashAdvanceAmount: Number.parseFloat(formData.cashAdvanceAmount),
        cashAdvanceSchedule: formData.cashAdvanceSchedule,
        isActive: true,
      })
      setIsAddDialogOpen(false)
    }
    setFormData({
      employeeId: "",
      name: "",
      type: "fixed",
      amount: "",
      cashAdvanceAmount: "0",
      cashAdvanceSchedule: "weekly",
    })
  }

  const handleEdit = (deduction: EmployeeDeduction) => {
    setEditingDeduction(deduction)
    setFormData({
      employeeId: deduction.employeeId,
      name: deduction.name,
      type: deduction.type,
      amount: deduction.amount.toString(),
      cashAdvanceAmount: (deduction.cashAdvanceAmount || 0).toString(),
      cashAdvanceSchedule: deduction.cashAdvanceSchedule || "weekly",
    })
  }

  const handleToggleActive = (id: string, isActive: boolean) => {
    onUpdateDeduction(id, { isActive: !isActive })
  }

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    const reader = new FileReader()
    reader.onload = (e) => {
      try {
        const text = e.target?.result as string
        const lines = text.split("\n")
        const headers = lines[0].split(",").map((h) => h.trim())

        const deductions = lines
          .slice(1)
          .filter((line) => line.trim())
          .map((line) => {
            const values = line.split(",").map((v) => v.trim())
            const employee = employees.find((emp) => emp.name === values[0])

            if (!employee) return null

            return {
              employeeId: employee.id,
              name: values[1],
              type: values[2] as "fixed" | "percentage",
              amount: Number.parseFloat(values[3]),
              isActive: values[4]?.toLowerCase() === "true",
            }
          })
          .filter(Boolean)

        onImportDeductions(deductions)
        alert(`Successfully imported ${deductions.length} deductions`)
      } catch (error) {
        alert("Error reading file. Please check the format.")
      }
    }
    reader.readAsText(file)
  }

  const exportTemplate = () => {
    const csvContent = [
      [
        "Employee Name",
        "Deduction Name",
        "Type",
        "Amount",
        "Cash Advance Amount",
        "Cash Advance Schedule",
        "Is Active",
      ],
      ["Maria Santos", "SSS", "fixed", "500", "0", "weekly", "true"],
      ["Maria Santos", "PhilHealth", "fixed", "400", "1000", "monthly", "true"],
      ["Juan Dela Cruz", "SSS", "fixed", "600", "0", "weekly", "true"],
    ]
      .map((row) => row.join(","))
      .join("\n")

    const blob = new Blob([csvContent], { type: "text/csv" })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = "deductions-template.csv"
    a.click()
    window.URL.revokeObjectURL(url)
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold text-gray-900">Deduction Management</h2>
          <p className="text-gray-600">Manage individual employee deductions (SSS, PhilHealth, Pag-IBIG, etc.)</p>
        </div>
        <div className="flex items-center space-x-4">
          <Button variant="outline" onClick={exportTemplate}>
            <Download className="h-4 w-4 mr-2" />
            Download Template
          </Button>
          <div className="relative">
            <input
              type="file"
              accept=".csv"
              onChange={handleFileUpload}
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
            />
            <Button variant="outline">
              <Upload className="h-4 w-4 mr-2" />
              Import CSV
            </Button>
          </div>
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Add Deduction
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add Employee Deduction</DialogTitle>
                <DialogDescription>Create a new deduction for an employee.</DialogDescription>
              </DialogHeader>
              <form onSubmit={handleSubmit}>
                <div className="grid gap-4 py-4">
                  <div className="grid gap-2">
                    <Label htmlFor="employee">Employee</Label>
                    <Select
                      value={formData.employeeId}
                      onValueChange={(value) => setFormData({ ...formData, employeeId: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select employee" />
                      </SelectTrigger>
                      <SelectContent>
                        {activeEmployees.map((employee) => (
                          <SelectItem key={employee.id} value={employee.id}>
                            {employee.name} - {employee.position}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="name">Deduction Name</Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="SSS, PhilHealth, Pag-IBIG, etc."
                      required
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="type">Type</Label>
                    <Select
                      value={formData.type}
                      onValueChange={(value: "fixed" | "percentage") => setFormData({ ...formData, type: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="fixed">Fixed Amount (₱)</SelectItem>
                        <SelectItem value="percentage">Percentage (%)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="amount">Amount {formData.type === "fixed" ? "(₱)" : "(%)"}</Label>
                    <Input
                      id="amount"
                      type="number"
                      step="0.01"
                      min="0"
                      value={formData.amount}
                      onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                      placeholder={formData.type === "fixed" ? "500.00" : "5.00"}
                      required
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="cashAdvanceAmount">Cash Advance Amount (₱)</Label>
                    <Input
                      id="cashAdvanceAmount"
                      type="number"
                      step="0.01"
                      min="0"
                      value={formData.cashAdvanceAmount}
                      onChange={(e) => setFormData({ ...formData, cashAdvanceAmount: e.target.value })}
                      placeholder="0.00"
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="cashAdvanceSchedule">Cash Advance Deduction Schedule</Label>
                    <Select
                      value={formData.cashAdvanceSchedule}
                      onValueChange={(value: "weekly" | "biweekly" | "monthly") =>
                        setFormData({ ...formData, cashAdvanceSchedule: value })
                      }
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="weekly">Weekly</SelectItem>
                        <SelectItem value="biweekly">Bi-weekly</SelectItem>
                        <SelectItem value="monthly">Monthly</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <DialogFooter>
                  <Button type="submit">Add Deduction</Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Filter */}
      <Card>
        <CardHeader>
          <CardTitle>Filter Deductions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center space-x-4">
            <Label htmlFor="employee-filter">Employee:</Label>
            <Select value={selectedEmployee} onValueChange={setSelectedEmployee}>
              <SelectTrigger className="w-64">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Employees</SelectItem>
                {activeEmployees.map((employee) => (
                  <SelectItem key={employee.id} value={employee.id}>
                    {employee.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Deductions List */}
      <Card>
        <CardHeader>
          <CardTitle>Employee Deductions</CardTitle>
          <CardDescription>Individual deductions per employee</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {filteredDeductions.length === 0 ? (
              <p className="text-gray-500 text-center py-8">No deductions found for the selected employee(s)</p>
            ) : (
              filteredDeductions.map((deduction) => {
                const employee = employees.find((emp) => emp.id === deduction.employeeId)
                return (
                  <div key={deduction.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center space-x-4">
                      <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                        <span className="text-blue-600 font-semibold">
                          {employee?.name
                            .split(" ")
                            .map((n) => n[0])
                            .join("")}
                        </span>
                      </div>
                      <div>
                        <h3 className="font-semibold">{employee?.name}</h3>
                        <p className="text-sm text-gray-600">{employee?.position}</p>
                      </div>
                      <div className="ml-8">
                        <h4 className="font-medium">{deduction.name}</h4>
                        <div className="flex items-center space-x-2">
                          <DollarSign className="h-4 w-4 text-green-600" />
                          <span className="text-green-600 font-medium">
                            {deduction.type === "fixed" ? `₱${deduction.amount.toFixed(2)}` : `${deduction.amount}%`}
                          </span>
                          <Badge variant={deduction.type === "fixed" ? "default" : "secondary"}>{deduction.type}</Badge>
                          {deduction.cashAdvanceAmount > 0 && (
                            <>
                              <Badge variant="outline">Cash Advance: ₱{deduction.cashAdvanceAmount.toFixed(2)}</Badge>
                              <Badge variant="outline">{deduction.cashAdvanceSchedule}</Badge>
                            </>
                          )}
                          <Badge variant={deduction.isActive ? "default" : "secondary"}>
                            {deduction.isActive ? "Active" : "Inactive"}
                          </Badge>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Button variant="outline" size="sm" onClick={() => handleEdit(deduction)}>
                        <Edit className="h-4 w-4 mr-1" />
                        Edit
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleToggleActive(deduction.id, deduction.isActive)}
                      >
                        {deduction.isActive ? "Deactivate" : "Activate"}
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => onDeleteDeduction(deduction.id)}
                        className="text-red-600 hover:text-red-700"
                      >
                        <Trash2 className="h-4 w-4 mr-1" />
                        Delete
                      </Button>
                    </div>
                  </div>
                )
              })
            )}
          </div>
        </CardContent>
      </Card>

      {/* Edit Dialog */}
      <Dialog open={!!editingDeduction} onOpenChange={() => setEditingDeduction(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Deduction</DialogTitle>
            <DialogDescription>Update deduction information.</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit}>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="edit-employee">Employee</Label>
                <Select
                  value={formData.employeeId}
                  onValueChange={(value) => setFormData({ ...formData, employeeId: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {activeEmployees.map((employee) => (
                      <SelectItem key={employee.id} value={employee.id}>
                        {employee.name} - {employee.position}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="edit-name">Deduction Name</Label>
                <Input
                  id="edit-name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="edit-type">Type</Label>
                <Select
                  value={formData.type}
                  onValueChange={(value: "fixed" | "percentage") => setFormData({ ...formData, type: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="fixed">Fixed Amount (₱)</SelectItem>
                    <SelectItem value="percentage">Percentage (%)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="edit-amount">Amount {formData.type === "fixed" ? "(₱)" : "(%)"}</Label>
                <Input
                  id="edit-amount"
                  type="number"
                  step="0.01"
                  min="0"
                  value={formData.amount}
                  onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                  required
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="cashAdvanceAmount">Cash Advance Amount (₱)</Label>
                <Input
                  id="cashAdvanceAmount"
                  type="number"
                  step="0.01"
                  min="0"
                  value={formData.cashAdvanceAmount}
                  onChange={(e) => setFormData({ ...formData, cashAdvanceAmount: e.target.value })}
                  placeholder="0.00"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="cashAdvanceSchedule">Cash Advance Deduction Schedule</Label>
                <Select
                  value={formData.cashAdvanceSchedule}
                  onValueChange={(value: "weekly" | "biweekly" | "monthly") =>
                    setFormData({ ...formData, cashAdvanceSchedule: value })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="weekly">Weekly</SelectItem>
                    <SelectItem value="biweekly">Bi-weekly</SelectItem>
                    <SelectItem value="monthly">Monthly</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setEditingDeduction(null)}>
                Cancel
              </Button>
              <Button type="submit">Update Deduction</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Import Instructions */}
      <Card>
        <CardHeader>
          <CardTitle>Excel Import Instructions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2 text-sm text-gray-600">
            <p>
              <strong>CSV Format:</strong> Employee Name, Deduction Name, Type, Amount, Cash Advance Amount, Cash
              Advance Schedule, Is Active
            </p>
            <p>
              <strong>Example:</strong> "Maria Santos,SSS,fixed,500,0,weekly,true"
            </p>
            <p>• Employee Name must match exactly with existing employee names</p>
            <p>• Type can be "fixed" or "percentage"</p>
            <p>• Amount should be numeric (no currency symbols)</p>
            <p>• Cash Advance Amount should be numeric (default: 0)</p>
            <p>• Cash Advance Schedule can be "weekly", "biweekly", or "monthly"</p>
            <p>• Is Active should be "true" or "false"</p>
            <p>• Download the template above for the correct format</p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
