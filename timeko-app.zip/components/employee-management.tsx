"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Plus, Edit, UserX, DollarSign, Key, Copy } from "lucide-react"

interface Employee {
  id: string
  name: string
  email: string
  hourlyRate: number
  position: string
  isActive: boolean
  role: "admin" | "employee"
  pincode: string
}

interface EmployeeManagementProps {
  employees: Employee[]
  onAddEmployee: (employee: Omit<Employee, "id" | "pincode">) => void
  onUpdateEmployee: (id: string, updates: Partial<Employee>) => void
}

export function EmployeeManagement({ employees, onAddEmployee, onUpdateEmployee }: EmployeeManagementProps) {
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [editingEmployee, setEditingEmployee] = useState<Employee | null>(null)
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    hourlyRate: "",
    position: "",
    role: "employee" as "admin" | "employee",
  })

  const positions = ["Crew", "Asst Store Supv", "Store Supv", "Reliever", "Other"]

  const generateNewPincode = () => {
    let pincode
    do {
      pincode = Math.floor(1000 + Math.random() * 9000).toString()
    } while (employees.some((emp) => emp.pincode === pincode))
    return pincode
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (editingEmployee) {
      onUpdateEmployee(editingEmployee.id, {
        name: formData.name,
        email: formData.email,
        hourlyRate: Number.parseFloat(formData.hourlyRate),
        position: formData.position,
        role: formData.role,
      })
      setEditingEmployee(null)
    } else {
      onAddEmployee({
        name: formData.name,
        email: formData.email,
        hourlyRate: Number.parseFloat(formData.hourlyRate),
        position: formData.position,
        role: formData.role,
        isActive: true,
      })
      setIsAddDialogOpen(false)
    }
    setFormData({ name: "", email: "", hourlyRate: "", position: "", role: "employee" })
  }

  const handleEdit = (employee: Employee) => {
    setEditingEmployee(employee)
    setFormData({
      name: employee.name,
      email: employee.email,
      hourlyRate: employee.hourlyRate.toString(),
      position: employee.position,
      role: employee.role,
    })
  }

  const handleDeactivate = (id: string) => {
    onUpdateEmployee(id, { isActive: false })
  }

  const handleReactivate = (id: string) => {
    onUpdateEmployee(id, { isActive: true })
  }

  const handleResetPincode = (id: string) => {
    const newPincode = generateNewPincode()
    onUpdateEmployee(id, { pincode: newPincode })
    alert(`New PIN code generated: ${newPincode}`)
  }

  const copyPincode = (pincode: string) => {
    navigator.clipboard.writeText(pincode)
    alert("PIN code copied to clipboard")
  }

  const activeEmployeeCount = employees.filter((emp) => emp.isActive && emp.role === "employee").length

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold text-gray-900">Employee Management</h2>
          <p className="text-gray-600">
            Manage your team members and their details ({activeEmployeeCount}/7 active employees)
          </p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button disabled={activeEmployeeCount >= 7}>
              <Plus className="h-4 w-4 mr-2" />
              Add Employee
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add New Employee</DialogTitle>
              <DialogDescription>
                Enter the details for the new team member. A unique PIN code will be automatically generated.
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit}>
              <div className="grid gap-4 py-4">
                <div className="grid gap-2">
                  <Label htmlFor="name">Full Name</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="Enter employee name"
                    required
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="email">Email Address</Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="employee@example.com"
                    required
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="position">Position</Label>
                  <Select
                    value={formData.position}
                    onValueChange={(value) => setFormData({ ...formData, position: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select position" />
                    </SelectTrigger>
                    <SelectContent>
                      {positions.map((position) => (
                        <SelectItem key={position} value={position}>
                          {position}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="role">Role</Label>
                  <Select
                    value={formData.role}
                    onValueChange={(value: "admin" | "employee") => setFormData({ ...formData, role: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="employee">Employee</SelectItem>
                      <SelectItem value="admin">Administrator</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="hourlyRate">Hourly Rate (₱)</Label>
                  <Input
                    id="hourlyRate"
                    type="number"
                    step="0.25"
                    min="0"
                    value={formData.hourlyRate}
                    onChange={(e) => setFormData({ ...formData, hourlyRate: e.target.value })}
                    placeholder="75.00"
                    required
                  />
                </div>
              </div>
              <DialogFooter>
                <Button type="submit">Add Employee</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {activeEmployeeCount >= 7 && (
        <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
          <p className="text-yellow-800">
            <strong>Maximum employees reached:</strong> You have reached the limit of 7 active employees. Deactivate an
            employee to add a new one.
          </p>
        </div>
      )}

      {/* Employee List */}
      <div className="grid gap-4">
        {employees.map((employee) => (
          <Card key={employee.id} className={employee.isActive ? "" : "opacity-60"}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                    <span className="text-blue-600 font-semibold text-lg">
                      {employee.name
                        .split(" ")
                        .map((n) => n[0])
                        .join("")}
                    </span>
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold">{employee.name}</h3>
                    <p className="text-gray-600">{employee.position}</p>
                    <p className="text-sm text-gray-500">{employee.email}</p>
                    <div className="flex items-center space-x-2 mt-1">
                      <DollarSign className="h-4 w-4 text-green-600" />
                      <span className="text-green-600 font-medium">₱{employee.hourlyRate.toFixed(2)}/hour</span>
                      <Badge variant={employee.isActive ? "default" : "secondary"}>
                        {employee.isActive ? "Active" : "Inactive"}
                      </Badge>
                      <Badge variant={employee.role === "admin" ? "destructive" : "outline"}>
                        {employee.role === "admin" ? "Administrator" : "Employee"}
                      </Badge>
                    </div>
                    <div className="flex items-center space-x-2 mt-2">
                      <Key className="h-4 w-4 text-gray-500" />
                      <span className="text-sm font-mono bg-gray-100 px-2 py-1 rounded">PIN: {employee.pincode}</span>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => copyPincode(employee.pincode)}
                        className="h-6 w-6 p-0"
                      >
                        <Copy className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Button variant="outline" size="sm" onClick={() => handleEdit(employee)}>
                    <Edit className="h-4 w-4 mr-1" />
                    Edit
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => handleResetPincode(employee.id)}>
                    <Key className="h-4 w-4 mr-1" />
                    Reset PIN
                  </Button>
                  {employee.isActive ? (
                    <Button variant="outline" size="sm" onClick={() => handleDeactivate(employee.id)}>
                      <UserX className="h-4 w-4 mr-1" />
                      Deactivate
                    </Button>
                  ) : (
                    <Button variant="outline" size="sm" onClick={() => handleReactivate(employee.id)}>
                      Reactivate
                    </Button>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Edit Dialog */}
      <Dialog open={!!editingEmployee} onOpenChange={() => setEditingEmployee(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Employee</DialogTitle>
            <DialogDescription>Update employee information.</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit}>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="edit-name">Full Name</Label>
                <Input
                  id="edit-name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="edit-email">Email Address</Label>
                <Input
                  id="edit-email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  required
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="edit-position">Position</Label>
                <Select
                  value={formData.position}
                  onValueChange={(value) => setFormData({ ...formData, position: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {positions.map((position) => (
                      <SelectItem key={position} value={position}>
                        {position}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="edit-role">Role</Label>
                <Select
                  value={formData.role}
                  onValueChange={(value: "admin" | "employee") => setFormData({ ...formData, role: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="employee">Employee</SelectItem>
                    <SelectItem value="admin">Administrator</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="edit-hourlyRate">Hourly Rate (₱)</Label>
                <Input
                  id="edit-hourlyRate"
                  type="number"
                  step="0.25"
                  min="0"
                  value={formData.hourlyRate}
                  onChange={(e) => setFormData({ ...formData, hourlyRate: e.target.value })}
                  required
                />
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setEditingEmployee(null)}>
                Cancel
              </Button>
              <Button type="submit">Update Employee</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  )
}
