"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Clock, Eye, EyeOff } from "lucide-react"

interface Employee {
  id: string
  name: string
  email: string
  role: "admin" | "employee"
  pincode: string
}

interface LoginFormProps {
  onLogin: (user: any) => void
  employees: Employee[]
}

export function LoginForm({ onLogin, employees }: LoginFormProps) {
  const [selectedEmployee, setSelectedEmployee] = useState("")
  const [pin, setPin] = useState("")
  const [error, setError] = useState("")
  const [showPin, setShowPin] = useState(false)

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault()
    setError("")

    if (!selectedEmployee) {
      setError("Please select an employee")
      return
    }

    const employee = employees.find((emp) => emp.id === selectedEmployee)
    if (!employee) {
      setError("Employee not found")
      return
    }

    // Validate PIN against employee's assigned pincode
    if (pin !== employee.pincode) {
      setError("Invalid PIN")
      return
    }

    onLogin({
      id: employee.id,
      name: employee.name,
      email: employee.email,
      role: employee.role,
      employeeId: employee.id,
    })
  }

  const selectedEmp = employees.find((emp) => emp.id === selectedEmployee)

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center">
      <div className="max-w-md w-full space-y-8">
        <div className="text-center">
          <div className="mx-auto h-12 w-12 bg-blue-600 rounded-lg flex items-center justify-center">
            <Clock className="h-8 w-8 text-white" />
          </div>
          <h2 className="mt-6 text-3xl font-bold text-gray-900">TimeKo</h2>
          <p className="mt-2 text-sm text-gray-600">Employee Time Tracker & Payroll System</p>
          <p className="text-xs text-gray-500">Philippines Edition</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Clock className="h-5 w-5" />
              <span>Login to TimeKo</span>
            </CardTitle>
            <CardDescription>Select your name and enter your assigned PIN to continue</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleLogin} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="employee">Select Employee</Label>
                <Select value={selectedEmployee} onValueChange={setSelectedEmployee}>
                  <SelectTrigger>
                    <SelectValue placeholder="Choose your name" />
                  </SelectTrigger>
                  <SelectContent>
                    {employees.map((employee) => (
                      <SelectItem key={employee.id} value={employee.id}>
                        {employee.name} ({employee.role === "admin" ? "Administrator" : employee.position})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {selectedEmp && (
                <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                      <span className="text-blue-600 font-semibold">
                        {selectedEmp.name
                          .split(" ")
                          .map((n) => n[0])
                          .join("")}
                      </span>
                    </div>
                    <div>
                      <p className="font-medium">{selectedEmp.name}</p>
                      <p className="text-sm text-gray-600">
                        {selectedEmp.role === "admin" ? "Administrator" : selectedEmp.position}
                      </p>
                      <p className="text-xs text-gray-500">PIN: {selectedEmp.pincode}</p>
                    </div>
                  </div>
                </div>
              )}

              <div className="space-y-2">
                <Label htmlFor="pin">PIN Code</Label>
                <div className="relative">
                  <Input
                    id="pin"
                    type={showPin ? "text" : "password"}
                    value={pin}
                    onChange={(e) => setPin(e.target.value)}
                    placeholder="Enter your assigned PIN"
                    maxLength={4}
                    className="pr-10"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPin(!showPin)}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                  >
                    {showPin ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>

              {error && <p className="text-sm text-red-600">{error}</p>}

              <Button type="submit" className="w-full">
                Login
              </Button>
            </form>

            <div className="mt-6 text-xs text-gray-500 space-y-1">
              <p>• Each employee has a unique 4-digit PIN assigned by the administrator</p>
              <p>• Contact your supervisor if you forgot your PIN</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
