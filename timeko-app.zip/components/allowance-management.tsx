"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Plus, Edit, Trash2, DollarSign } from "lucide-react"

interface Employee {
  id: string
  name: string
  position: string
  role: "admin" | "employee"
}

interface EmployeeAllowance {
  id: string
  employeeId: string
  weekStartDate: string
  amount: number
  description: string
}

interface AllowanceManagementProps {
  employees: Employee[]
  employeeAllowances: EmployeeAllowance[]
  onAddAllowance: (allowance: Omit<EmployeeAllowance, "id">) => void
  onUpdateAllowance: (id: string, updates: Partial<EmployeeAllowance>) => void
  onDeleteAllowance: (id: string) => void
}

export function AllowanceManagement({
  employees,
  employeeAllowances,
  onAddAllowance,
  onUpdateAllowance,
  onDeleteAllowance,
}: AllowanceManagementProps) {
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [editingAllowance, setEditingAllowance] = useState<EmployeeAllowance | null>(null)
  const [selectedEmployee, setSelectedEmployee] = useState("all")
  const [formData, setFormData] = useState({
    employeeId: "",
    weekStartDate: "",
    amount: "0",
    description: "Allowance",
  })

  const activeEmployees = employees.filter((emp) => emp.role === "employee")

  const filteredAllowances = employeeAllowances.filter(
    (allowance) => selectedEmployee === "all" || allowance.employeeId === selectedEmployee,
  )

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (editingAllowance) {
      onUpdateAllowance(editingAllowance.id, {
        employeeId: formData.employeeId,
        weekStartDate: formData.weekStartDate,
        amount: Number.parseFloat(formData.amount),
        description: formData.description,
      })
      setEditingAllowance(null)
    } else {
      onAddAllowance({
        employeeId: formData.employeeId,
        weekStartDate: formData.weekStartDate,
        amount: Number.parseFloat(formData.amount),
        description: formData.description,
      })
      setIsAddDialogOpen(false)
    }
    setFormData({ employeeId: "", weekStartDate: "", amount: "0", description: "Allowance" })
  }

  const handleEdit = (allowance: EmployeeAllowance) => {
    setEditingAllowance(allowance)
    setFormData({
      employeeId: allowance.employeeId,
      weekStartDate: allowance.weekStartDate,
      amount: allowance.amount.toString(),
      description: allowance.description,
    })
  }

  // Get the current week's start date (Monday)
  const getCurrentWeekStart = () => {
    const now = new Date()
    const day = now.getDay()
    const diff = now.getDate() - day + (day === 0 ? -6 : 1) // Adjust for Sunday
    return new Date(now.setDate(diff)).toISOString().split("T")[0]
  }

  // Group allowances by employee
  const allowancesByEmployee = filteredAllowances.reduce(
    (acc, allowance) => {
      if (!acc[allowance.employeeId]) {
        acc[allowance.employeeId] = []
      }
      acc[allowance.employeeId].push(allowance)
      return acc
    },
    {} as Record<string, EmployeeAllowance[]>,
  )

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold text-gray-900">Allowance Management</h2>
          <p className="text-gray-600">Manage weekly allowances for employees</p>
        </div>
        <div className="flex items-center space-x-4">
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Add Allowance
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add Weekly Allowance</DialogTitle>
                <DialogDescription>Create a new weekly allowance for an employee.</DialogDescription>
              </DialogHeader>
              <form onSubmit={handleSubmit}>
                <div className="grid gap-4 py-4">
                  <div className="grid gap-2">
                    <Label htmlFor="employee">Employee</Label>
                    <Select
                      value={formData.employeeId}
                      onValueChange={(value) => setFormData({ ...formData, employeeId: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select employee" />
                      </SelectTrigger>
                      <SelectContent>
                        {activeEmployees.map((employee) => (
                          <SelectItem key={employee.id} value={employee.id}>
                            {employee.name} - {employee.position}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="weekStartDate">Week Start Date</Label>
                    <Input
                      id="weekStartDate"
                      type="date"
                      value={formData.weekStartDate}
                      onChange={(e) => setFormData({ ...formData, weekStartDate: e.target.value })}
                      required
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="amount">Amount (₱)</Label>
                    <Input
                      id="amount"
                      type="number"
                      step="0.01"
                      min="0"
                      value={formData.amount}
                      onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                      placeholder="0.00"
                      required
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="description">Description</Label>
                    <Input
                      id="description"
                      value={formData.description}
                      onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                      placeholder="Allowance"
                      required
                    />
                  </div>
                </div>
                <DialogFooter>
                  <Button type="submit">Add Allowance</Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Filter */}
      <Card>
        <CardHeader>
          <CardTitle>Filter Allowances</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center space-x-4">
            <Label htmlFor="employee-filter">Employee:</Label>
            <Select value={selectedEmployee} onValueChange={setSelectedEmployee}>
              <SelectTrigger className="w-64">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Employees</SelectItem>
                {activeEmployees.map((employee) => (
                  <SelectItem key={employee.id} value={employee.id}>
                    {employee.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Allowances List */}
      <Card>
        <CardHeader>
          <CardTitle>Employee Allowances</CardTitle>
          <CardDescription>Weekly allowances per employee</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {filteredAllowances.length === 0 ? (
              <p className="text-gray-500 text-center py-8">No allowances found for the selected employee(s)</p>
            ) : (
              filteredAllowances
                .sort((a, b) => new Date(b.weekStartDate).getTime() - new Date(a.weekStartDate).getTime())
                .map((allowance) => {
                  const employee = employees.find((emp) => emp.id === allowance.employeeId)
                  return (
                    <div key={allowance.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center space-x-4">
                        <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                          <span className="text-green-600 font-semibold">
                            {employee?.name
                              .split(" ")
                              .map((n) => n[0])
                              .join("")}
                          </span>
                        </div>
                        <div>
                          <h3 className="font-semibold">{employee?.name}</h3>
                          <p className="text-sm text-gray-600">{employee?.position}</p>
                        </div>
                        <div className="ml-8">
                          <h4 className="font-medium">{allowance.description}</h4>
                          <div className="flex items-center space-x-2">
                            <DollarSign className="h-4 w-4 text-green-600" />
                            <span className="text-green-600 font-medium">₱{allowance.amount.toFixed(2)}</span>
                            <Badge variant="outline">
                              Week of {new Date(allowance.weekStartDate).toLocaleDateString()}
                            </Badge>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Button variant="outline" size="sm" onClick={() => handleEdit(allowance)}>
                          <Edit className="h-4 w-4 mr-1" />
                          Edit
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => onDeleteAllowance(allowance.id)}
                          className="text-red-600 hover:text-red-700"
                        >
                          <Trash2 className="h-4 w-4 mr-1" />
                          Delete
                        </Button>
                      </div>
                    </div>
                  )
                })
            )}
          </div>
        </CardContent>
      </Card>

      {/* Edit Dialog */}
      <Dialog open={!!editingAllowance} onOpenChange={() => setEditingAllowance(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Allowance</DialogTitle>
            <DialogDescription>Update allowance information.</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit}>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="edit-employee">Employee</Label>
                <Select
                  value={formData.employeeId}
                  onValueChange={(value) => setFormData({ ...formData, employeeId: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {activeEmployees.map((employee) => (
                      <SelectItem key={employee.id} value={employee.id}>
                        {employee.name} - {employee.position}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="edit-weekStartDate">Week Start Date</Label>
                <Input
                  id="edit-weekStartDate"
                  type="date"
                  value={formData.weekStartDate}
                  onChange={(e) => setFormData({ ...formData, weekStartDate: e.target.value })}
                  required
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="edit-amount">Amount (₱)</Label>
                <Input
                  id="edit-amount"
                  type="number"
                  step="0.01"
                  min="0"
                  value={formData.amount}
                  onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                  required
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="edit-description">Description</Label>
                <Input
                  id="edit-description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  required
                />
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setEditingAllowance(null)}>
                Cancel
              </Button>
              <Button type="submit">Update Allowance</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Instructions */}
      <Card>
        <CardHeader>
          <CardTitle>Allowance Instructions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2 text-sm text-gray-600">
            <p>• Allowances are calculated per week starting from the specified date</p>
            <p>• Common allowances include transportation, meal, and uniform allowances</p>
            <p>• Allowances are added to the employee's net pay during payroll calculation</p>
            <p>• Week start date should typically be a Monday</p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
