"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Upload, Save, Building2, ImageIcon, FileImage } from "lucide-react"

interface CompanySettings {
  name: string
  address: string
  logoUrl?: string
  headerUrl?: string
}

interface CompanySettingsProps {
  settings: CompanySettings
  onUpdateSettings: (settings: CompanySettings) => void
}

export function CompanySettings({ settings, onUpdateSettings }: CompanySettingsProps) {
  const [formData, setFormData] = useState<CompanySettings>(settings)
  const [logoPreview, setLogoPreview] = useState<string | null>(settings.logoUrl || null)
  const [headerPreview, setHeaderPreview] = useState<string | null>(settings.headerUrl || null)

  const handleLogoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (e) => {
        const result = e.target?.result as string
        setLogoPreview(result)
        setFormData({ ...formData, logoUrl: result })
      }
      reader.readAsDataURL(file)
    }
  }

  const handleHeaderUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (e) => {
        const result = e.target?.result as string
        setHeaderPreview(result)
        setFormData({ ...formData, headerUrl: result })
      }
      reader.readAsDataURL(file)
    }
  }

  const handleSave = () => {
    onUpdateSettings(formData)
    alert("Company settings saved successfully!")
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold text-gray-900">Company Settings</h2>
        <p className="text-gray-600">Configure company information for reports and payslips</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Company Information */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Building2 className="h-5 w-5" />
              <span>Company Information</span>
            </CardTitle>
            <CardDescription>Basic company details that will appear on all documents</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-2">
              <Label htmlFor="companyName">Company Name</Label>
              <Input
                id="companyName"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="Enter company name"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="companyAddress">Company Address</Label>
              <Textarea
                id="companyAddress"
                value={formData.address}
                onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                placeholder="Enter complete company address"
                rows={3}
              />
            </div>
          </CardContent>
        </Card>

        {/* Company Logo */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <ImageIcon className="h-5 w-5" />
              <span>Company Logo</span>
            </CardTitle>
            <CardDescription>Upload your company logo (recommended: square format, max 2MB)</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex flex-col items-center space-y-4">
              {logoPreview ? (
                <div className="relative">
                  <img
                    src={logoPreview || "/placeholder.svg"}
                    alt="Company Logo"
                    className="h-24 w-24 object-contain border rounded"
                  />
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setLogoPreview(null)
                      setFormData({ ...formData, logoUrl: undefined })
                    }}
                    className="absolute -top-2 -right-2 h-6 w-6 rounded-full p-0"
                  >
                    ×
                  </Button>
                </div>
              ) : (
                <div className="h-24 w-24 border-2 border-dashed border-gray-300 rounded flex items-center justify-center">
                  <ImageIcon className="h-8 w-8 text-gray-400" />
                </div>
              )}
              <div className="relative">
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleLogoUpload}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                />
                <Button variant="outline">
                  <Upload className="h-4 w-4 mr-2" />
                  Upload Logo
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Company Header */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <FileImage className="h-5 w-5" />
              <span>Company Header Image</span>
            </CardTitle>
            <CardDescription>Upload a header image for documents (recommended: wide format, max 2MB)</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex flex-col items-center space-y-4">
              {headerPreview ? (
                <div className="relative">
                  <img
                    src={headerPreview || "/placeholder.svg"}
                    alt="Company Header"
                    className="h-20 w-full max-w-md object-contain border rounded"
                  />
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setHeaderPreview(null)
                      setFormData({ ...formData, headerUrl: undefined })
                    }}
                    className="absolute -top-2 -right-2 h-6 w-6 rounded-full p-0"
                  >
                    ×
                  </Button>
                </div>
              ) : (
                <div className="h-20 w-full max-w-md border-2 border-dashed border-gray-300 rounded flex items-center justify-center">
                  <FileImage className="h-8 w-8 text-gray-400" />
                </div>
              )}
              <div className="relative">
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleHeaderUpload}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                />
                <Button variant="outline">
                  <Upload className="h-4 w-4 mr-2" />
                  Upload Header Image
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Preview */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Preview</CardTitle>
            <CardDescription>How your company information will appear on documents</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="border rounded-lg p-6 bg-white">
              {/* Header Image */}
              {headerPreview && (
                <div className="mb-4">
                  <img src={headerPreview || "/placeholder.svg"} alt="Header" className="w-full h-16 object-contain" />
                </div>
              )}

              {/* Company Info */}
              <div className="flex items-center space-x-4 mb-4">
                {logoPreview && (
                  <img src={logoPreview || "/placeholder.svg"} alt="Logo" className="h-12 w-12 object-contain" />
                )}
                <div>
                  <h1 className="text-xl font-bold">{formData.name || "Company Name"}</h1>
                  {formData.address && <p className="text-sm text-gray-600">{formData.address}</p>}
                </div>
              </div>

              {/* Sample Document Content */}
              <div className="border-t pt-4">
                <h2 className="font-semibold mb-2">EMPLOYEE PAYSLIP</h2>
                <p className="text-sm text-gray-600">
                  This is how your company branding will appear on payslips and reports.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Save Button */}
      <div className="flex justify-end">
        <Button onClick={handleSave} className="flex items-center space-x-2">
          <Save className="h-4 w-4" />
          <span>Save Settings</span>
        </Button>
      </div>
    </div>
  )
}
