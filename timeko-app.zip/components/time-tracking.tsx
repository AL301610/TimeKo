"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Clock, LogIn, LogOut, AlertCircle, CheckCircle, Clock3, Edit } from "lucide-react"

interface User {
  id: string
  name: string
  email: string
  role: "admin" | "employee"
  employeeId?: string
}

interface Employee {
  id: string
  name: string
  hourlyRate: number
  position: string
  role: "admin" | "employee"
}

interface Schedule {
  id: string
  employeeId: string
  date: string
  startTime: string
  endTime: string
  dayType: "regular" | "sunday" | "holiday"
  isRestDay: boolean
}

interface TimeEntry {
  id: string
  employeeId: string
  date: string
  clockIn?: string
  clockOut?: string
  hoursWorked: number
  isLate: boolean
  lateMinutes: number
  lateReason?: string
  isAbsent: boolean
  status: "on-time" | "late" | "absent"
  clockInComment?: string
  clockOutComment?: string
  adminOverride?: boolean
}

interface TimeTrackingProps {
  currentUser: User
  employees: Employee[]
  schedules: Schedule[]
  timeEntries: TimeEntry[]
  onAddTimeEntry: (entry: Omit<TimeEntry, "id">) => void
  onUpdateTimeEntry: (id: string, updates: Partial<TimeEntry>) => void
}

export function TimeTracking({
  currentUser,
  employees,
  schedules,
  timeEntries,
  onAddTimeEntry,
  onUpdateTimeEntry,
}: TimeTrackingProps) {
  const [message, setMessage] = useState<{ type: "success" | "error"; text: string } | null>(null)
  const [manualTimeIn, setManualTimeIn] = useState("")
  const [manualTimeOut, setManualTimeOut] = useState("")
  const [lateReason, setLateReason] = useState("")
  const [clockInComment, setClockInComment] = useState("")
  const [clockOutComment, setClockOutComment] = useState("")
  const [showLateReasonDialog, setShowLateReasonDialog] = useState(false)
  const [showAdminOverrideDialog, setShowAdminOverrideDialog] = useState(false)
  const [adminOverrideEntry, setAdminOverrideEntry] = useState<TimeEntry | null>(null)
  const [adminOverrideData, setAdminOverrideData] = useState({
    clockIn: "",
    clockOut: "",
    comment: "",
  })

  const [showCertificationDialog, setShowCertificationDialog] = useState(false)
  const [certificationAction, setCertificationAction] = useState<"in" | "out">("in")
  const [pendingTimeData, setPendingTimeData] = useState<any>(null)

  const today = new Date().toISOString().split("T")[0]
  const currentTime = new Date()
  const currentTimeString = currentTime.toLocaleTimeString("en-US", {
    hour12: false,
    hour: "2-digit",
    minute: "2-digit",
  })

  const isAdmin = currentUser.role === "admin"
  const currentEmployee = employees.find((emp) => emp.id === currentUser.employeeId || emp.email === currentUser.email)

  // Get today's schedule for current employee
  const todaySchedule = schedules.find(
    (schedule) => schedule.employeeId === currentEmployee?.id && schedule.date === today,
  )

  // Get today's time entry for current employee
  const todayEntry = timeEntries.find((entry) => entry.employeeId === currentEmployee?.id && entry.date === today)

  const validateTimeEntry = (action: "in" | "out", time: string) => {
    if (!todaySchedule) {
      return { valid: false, message: "No schedule found for today" }
    }

    // Parse the time string
    const [hours, minutes] = time.split(":").map(Number)
    const entryTime = new Date()
    entryTime.setHours(hours, minutes, 0, 0)

    // For time out, check if it's before 22:00 (10 PM)
    if (action === "out") {
      const maxTimeOut = new Date()
      maxTimeOut.setHours(22, 0, 0, 0) // Changed from 23 to 22

      if (entryTime > maxTimeOut && !isAdmin) {
        return { valid: false, message: "Time out cannot be after 10:00 PM. Please contact admin for override." }
      }

      return { valid: true, message: "Valid time entry", isLate: false }
    }

    // For time in, check against schedule
    const [scheduleHour, scheduleMinute] = todaySchedule.startTime.split(":").map(Number)
    const scheduleTime = new Date()
    scheduleTime.setHours(scheduleHour, scheduleMinute, 0, 0)

    // Grace period (5 minutes)
    const graceTime = new Date(scheduleTime.getTime() + 5 * 60 * 1000)

    if (entryTime > graceTime) {
      // Late, but valid with reason
      const lateMinutes = Math.floor((entryTime.getTime() - scheduleTime.getTime()) / (60 * 1000))
      return { valid: true, message: "Late arrival", isLate: true, lateMinutes, requiresReason: true }
    }

    return { valid: true, message: "Valid time entry", isLate: false }
  }

  const calculateHours = (clockIn: string, clockOut: string) => {
    const [inHour, inMin] = clockIn.split(":").map(Number)
    const [outHour, outMin] = clockOut.split(":").map(Number)

    const inMinutes = inHour * 60 + inMin
    const outMinutes = outHour * 60 + outMin

    // Subtract 1 hour for break
    const totalMinutes = outMinutes - inMinutes - 60
    return Math.max(0, totalMinutes / 60)
  }

  const getLateMinutes = (clockIn: string, scheduledStart: string) => {
    const [clockHour, clockMin] = clockIn.split(":").map(Number)
    const [schedHour, schedMin] = scheduledStart.split(":").map(Number)

    const clockMinutes = clockHour * 60 + clockMin
    const schedMinutes = schedHour * 60 + schedMin

    return Math.max(0, clockMinutes - schedMinutes)
  }

  const handleCertificationConfirm = () => {
    if (certificationAction === "in") {
      // Proceed with clock in
      const timeToUse = pendingTimeData.useCurrentTime ? currentTimeString : manualTimeIn
      const validation = validateTimeEntry("in", timeToUse)

      if (validation.isLate && validation.requiresReason) {
        setShowLateReasonDialog(true)
      } else {
        const lateMinutes = validation.isLate ? getLateMinutes(timeToUse, todaySchedule.startTime) : 0
        onAddTimeEntry({
          employeeId: currentEmployee.id,
          date: today,
          clockIn: timeToUse,
          hoursWorked: 0,
          isLate: validation.isLate || false,
          lateMinutes: lateMinutes,
          lateReason: lateReason,
          isAbsent: false,
          status: validation.isLate ? "late" : "on-time",
          clockInComment: clockInComment,
        })
        setMessage({
          type: "success",
          text: validation.isLate ? "Clocked in (Late)" : "Successfully clocked in",
        })
        setManualTimeIn("")
        setLateReason("")
        setClockInComment("")
      }
    } else {
      // Proceed with clock out
      const timeToUse = pendingTimeData.useCurrentTime ? currentTimeString : manualTimeOut
      const hours = calculateHours(todayEntry.clockIn, timeToUse)
      onUpdateTimeEntry(todayEntry.id, {
        clockOut: timeToUse,
        hoursWorked: hours,
        clockOutComment: clockOutComment,
      })
      setMessage({ type: "success", text: "Successfully clocked out" })
      setManualTimeOut("")
      setClockOutComment("")
    }

    setShowCertificationDialog(false)
    setPendingTimeData(null)
  }

  const handleClockIn = (useCurrentTime = false) => {
    if (!currentEmployee || !todaySchedule) return

    const timeToUse = useCurrentTime ? currentTimeString : manualTimeIn

    if (!timeToUse) {
      setMessage({ type: "error", text: "Please enter a valid time" })
      return
    }

    const validation = validateTimeEntry("in", timeToUse)
    if (!validation.valid) {
      setMessage({ type: "error", text: validation.message })
      return
    }

    // Show certification dialog
    setCertificationAction("in")
    setPendingTimeData({ useCurrentTime })
    setShowCertificationDialog(true)
  }

  const handleSubmitLateReason = () => {
    if (!currentEmployee || !todaySchedule) return

    if (!lateReason.trim()) {
      setMessage({ type: "error", text: "Please provide a reason for being late" })
      return
    }

    // Use manualTimeIn if available, otherwise use current time
    const timeToUse = manualTimeIn || currentTimeString
    const lateMinutes = getLateMinutes(timeToUse, todaySchedule.startTime)

    onAddTimeEntry({
      employeeId: currentEmployee.id,
      date: today,
      clockIn: timeToUse,
      hoursWorked: 0,
      isLate: true,
      lateMinutes: lateMinutes,
      lateReason: lateReason,
      isAbsent: false,
      status: "late",
      clockInComment: clockInComment,
    })

    setMessage({
      type: "success",
      text: "Clocked in (Late)",
    })

    // Reset form and close dialog
    setManualTimeIn("")
    setLateReason("")
    setClockInComment("")
    setShowLateReasonDialog(false)
  }

  const handleClockOut = (useCurrentTime = false) => {
    if (!currentEmployee || !todayEntry || !todayEntry.clockIn) return

    const timeToUse = useCurrentTime ? currentTimeString : manualTimeOut

    if (!timeToUse) {
      setMessage({ type: "error", text: "Please enter a valid time" })
      return
    }

    const validation = validateTimeEntry("out", timeToUse)
    if (!validation.valid) {
      setMessage({ type: "error", text: validation.message })
      return
    }

    // Show certification dialog
    setCertificationAction("out")
    setPendingTimeData({ useCurrentTime })
    setShowCertificationDialog(true)
  }

  const handleAdminOverride = (entry: TimeEntry) => {
    setAdminOverrideEntry(entry)
    setAdminOverrideData({
      clockIn: entry.clockIn || "",
      clockOut: entry.clockOut || "",
      comment: "",
    })
    setShowAdminOverrideDialog(true)
  }

  const handleSubmitAdminOverride = () => {
    if (!adminOverrideEntry) return

    onUpdateTimeEntry(adminOverrideEntry.id, {
      clockIn: adminOverrideData.clockIn || adminOverrideEntry.clockIn,
      clockOut: adminOverrideData.clockOut || adminOverrideEntry.clockOut,
      hoursWorked:
        adminOverrideData.clockIn && adminOverrideData.clockOut
          ? calculateHours(adminOverrideData.clockIn, adminOverrideData.clockOut)
          : adminOverrideEntry.hoursWorked,
      adminOverride: true,
    })

    setMessage({ type: "success", text: "Time entry updated by admin" })
    setShowAdminOverrideDialog(false)
    setAdminOverrideEntry(null)
  }

  // Clear message after 5 seconds
  if (message) {
    setTimeout(() => setMessage(null), 5000)
  }

  if (!currentEmployee) {
    return <div>Employee not found</div>
  }

  // Format time for input fields
  const formatTimeForInput = (timeString: string) => {
    if (!timeString) return ""
    return timeString
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold text-gray-900">Time In/Out</h2>
        <p className="text-gray-600">
          {isAdmin ? "Admin view - Employee time tracking" : "Clock in and out for your shifts"}
        </p>
      </div>

      {message && (
        <Alert className={message.type === "error" ? "border-red-200 bg-red-50" : "border-green-200 bg-green-50"}>
          <AlertCircle className="h-4 w-4" />
          <AlertDescription className={message.type === "error" ? "text-red-800" : "text-green-800"}>
            {message.text}
          </AlertDescription>
        </Alert>
      )}

      {/* Current Time and Schedule */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Clock className="h-5 w-5" />
            <span>Current Time & Schedule</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <p className="text-sm text-gray-500">Current Time</p>
              <p className="text-2xl font-bold">{currentTimeString}</p>
              <p className="text-xs text-gray-400">{new Date().toLocaleDateString()}</p>
            </div>
            {todaySchedule ? (
              <>
                <div>
                  <p className="text-sm text-gray-500">Scheduled Start</p>
                  <p className="text-lg font-semibold">{todaySchedule.startTime}</p>
                  <Badge variant={todaySchedule.dayType === "regular" ? "default" : "secondary"}>
                    {todaySchedule.dayType}
                  </Badge>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Scheduled End</p>
                  <p className="text-lg font-semibold">{todaySchedule.endTime}</p>
                  <p className="text-xs text-gray-400">
                    {(() => {
                      const [startHour, startMin] = todaySchedule.startTime.split(":").map(Number)
                      const [endHour, endMin] = todaySchedule.endTime.split(":").map(Number)
                      const totalMinutes = endHour * 60 + endMin - (startHour * 60 + startMin) - 60 // minus 1hr break
                      return `${(totalMinutes / 60).toFixed(1)} hours (with 1hr break)`
                    })()}
                  </p>
                </div>
              </>
            ) : (
              <div className="col-span-2">
                <p className="text-sm text-gray-500">No schedule for today</p>
                <p className="text-gray-400">Contact your administrator</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Time Entry Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Time Entry</CardTitle>
          <CardDescription>Clock in when you arrive and clock out when you leave</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {todayEntry ? (
              <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">Today's Entry</p>
                    <div className="flex items-center space-x-4 mt-2">
                      <div>
                        <p className="text-sm text-gray-500">Clock In</p>
                        <p className="font-semibold">{todayEntry.clockIn || "Not clocked in"}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-500">Clock Out</p>
                        <p className="font-semibold">{todayEntry.clockOut || "Not clocked out"}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-500">Hours Worked</p>
                        <p className="font-semibold">{todayEntry.hoursWorked.toFixed(1)} hrs</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-500">Status</p>
                        <Badge
                          variant={
                            todayEntry.status === "on-time"
                              ? "default"
                              : todayEntry.status === "late"
                                ? "destructive"
                                : "secondary"
                          }
                        >
                          {todayEntry.status}
                        </Badge>
                      </div>
                    </div>
                    {todayEntry.isLate && (
                      <div className="mt-1">
                        <p className="text-sm text-red-600">Late by {todayEntry.lateMinutes} minutes</p>
                        {todayEntry.lateReason && (
                          <p className="text-sm text-gray-600">Reason: {todayEntry.lateReason}</p>
                        )}
                      </div>
                    )}
                    {todayEntry.clockInComment && (
                      <p className="text-sm text-blue-600 mt-1">Clock-in comment: {todayEntry.clockInComment}</p>
                    )}
                    {todayEntry.clockOutComment && (
                      <p className="text-sm text-blue-600 mt-1">Clock-out comment: {todayEntry.clockOutComment}</p>
                    )}
                    {todayEntry.adminOverride && (
                      <p className="text-sm text-purple-600 mt-1">
                        <span className="font-semibold">Admin override</span> - Time manually adjusted by administrator
                      </p>
                    )}
                  </div>
                  <div className="flex flex-col space-y-2">
                    {!todayEntry.clockOut && todayEntry.clockIn && (
                      <div className="space-y-4">
                        <div className="grid gap-2">
                          <Label htmlFor="manualTimeOut">Time Out</Label>
                          <div className="flex space-x-2">
                            <Input
                              id="manualTimeOut"
                              type="time"
                              value={manualTimeOut}
                              onChange={(e) => setManualTimeOut(e.target.value)}
                              className="w-32"
                            />
                            <Button onClick={() => handleClockOut(true)} className="flex items-center space-x-1">
                              <Clock3 className="h-4 w-4" />
                              <span>Use Current</span>
                            </Button>
                          </div>
                        </div>
                        <div className="grid gap-2">
                          <Label htmlFor="clockOutComment">Comment (Optional)</Label>
                          <Textarea
                            id="clockOutComment"
                            placeholder="Add a comment for your supervisor"
                            value={clockOutComment}
                            onChange={(e) => setClockOutComment(e.target.value)}
                            className="h-20"
                          />
                        </div>
                        <Button onClick={() => handleClockOut(false)} className="w-full">
                          <LogOut className="h-4 w-4 mr-2" />
                          <span>Clock Out</span>
                        </Button>
                      </div>
                    )}
                    {todayEntry.clockOut && (
                      <div className="flex items-center space-x-2 text-green-600">
                        <CheckCircle className="h-4 w-4" />
                        <span className="text-sm">Completed</span>
                      </div>
                    )}
                    {isAdmin && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleAdminOverride(todayEntry)}
                        className="mt-2"
                      >
                        <Edit className="h-4 w-4 mr-1" />
                        Admin Override
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            ) : (
              <div className="space-y-6">
                <div className="grid gap-4">
                  <div className="grid gap-2">
                    <Label htmlFor="manualTimeIn">Time In</Label>
                    <div className="flex space-x-2">
                      <Input
                        id="manualTimeIn"
                        type="time"
                        value={manualTimeIn}
                        onChange={(e) => setManualTimeIn(e.target.value)}
                        className="w-32"
                      />
                      <Button onClick={() => handleClockIn(true)} className="flex items-center space-x-1">
                        <Clock3 className="h-4 w-4" />
                        <span>Use Current</span>
                      </Button>
                    </div>
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="clockInComment">Comment (Optional)</Label>
                    <Textarea
                      id="clockInComment"
                      placeholder="Add a comment for your supervisor"
                      value={clockInComment}
                      onChange={(e) => setClockInComment(e.target.value)}
                      className="h-20"
                    />
                  </div>
                  <Button
                    onClick={() => handleClockIn(false)}
                    disabled={!todaySchedule || !manualTimeIn}
                    className="w-full"
                  >
                    <LogIn className="h-4 w-4 mr-2" />
                    <span>Clock In</span>
                  </Button>
                </div>
                {!todaySchedule && (
                  <p className="text-sm text-red-600 mt-2">No schedule found for today. Contact your administrator.</p>
                )}
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Admin Section - Recent Time Entries */}
      {isAdmin && (
        <Card>
          <CardHeader>
            <CardTitle>Recent Time Entries</CardTitle>
            <CardDescription>View and manage employee time entries</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {timeEntries
                .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                .slice(0, 10)
                .map((entry) => {
                  const employee = employees.find((emp) => emp.id === entry.employeeId)
                  if (!employee) return null

                  return (
                    <div key={entry.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                          <span className="text-blue-600 font-semibold">
                            {employee.name
                              .split(" ")
                              .map((n) => n[0])
                              .join("")}
                          </span>
                        </div>
                        <div>
                          <h3 className="font-semibold">{employee.name}</h3>
                          <p className="text-sm text-gray-600">{new Date(entry.date).toLocaleDateString()}</p>
                          {entry.isLate && (
                            <div className="flex items-center space-x-1 text-red-600 text-xs">
                              <AlertCircle className="h-3 w-3" />
                              <span>Late by {entry.lateMinutes} min</span>
                            </div>
                          )}
                          {entry.lateReason && <p className="text-xs text-gray-600">Reason: {entry.lateReason}</p>}
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="flex items-center space-x-2">
                          <span className="text-sm">
                            {entry.clockIn || "No clock in"} - {entry.clockOut || "Working"}
                          </span>
                          <Badge
                            variant={
                              entry.status === "on-time"
                                ? "default"
                                : entry.status === "late"
                                  ? "destructive"
                                  : "secondary"
                            }
                          >
                            {entry.status}
                          </Badge>
                          {entry.adminOverride && (
                            <Badge variant="outline" className="text-xs">
                              Admin Override
                            </Badge>
                          )}
                        </div>
                        <p className="text-xs text-gray-500">
                          {entry.hoursWorked.toFixed(1)} hours • ₱{(entry.hoursWorked * employee.hourlyRate).toFixed(2)}
                        </p>
                        <Button variant="outline" size="sm" onClick={() => handleAdminOverride(entry)} className="mt-2">
                          <Edit className="h-3 w-3 mr-1" />
                          Override
                        </Button>
                      </div>
                    </div>
                  )
                })}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Time Entry Rules */}
      <Card>
        <CardHeader>
          <CardTitle>Time Entry Rules</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            <div>
              <h4 className="font-semibold mb-2">Clock In Rules:</h4>
              <ul className="space-y-1 text-gray-600">
                <li>• Must be within 5 minutes of scheduled start time</li>
                <li>• Late arrivals &gt;5 min) require a reason</li>
                <li>• Manual time entry available with validation</li>
                <li>• Must have a schedule for the day</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-2">Clock Out Rules:</h4>
              <ul className="space-y-1 text-gray-600">
                <li>• Maximum time out is 10:00 PM</li>
                <li>• Admin can override time entries if needed</li>
                <li>• 1 hour break automatically deducted</li>
                <li>• Optional comments for supervisor</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Late Reason Dialog */}
      <Dialog open={showLateReasonDialog} onOpenChange={setShowLateReasonDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Late Arrival</DialogTitle>
            <DialogDescription>
              You are clocking in late. Please provide a reason for your late arrival.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="lateReason">Reason for Late Arrival</Label>
              <Textarea
                id="lateReason"
                placeholder="Please explain why you are late"
                value={lateReason}
                onChange={(e) => setLateReason(e.target.value)}
                className="h-24"
                required
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowLateReasonDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleSubmitLateReason}>Submit & Clock In</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Admin Override Dialog */}
      <Dialog open={showAdminOverrideDialog} onOpenChange={setShowAdminOverrideDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Admin Time Override</DialogTitle>
            <DialogDescription>
              As an administrator, you can override the time entry for this employee.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="adminClockIn">Clock In Time</Label>
                <Input
                  id="adminClockIn"
                  type="time"
                  value={adminOverrideData.clockIn}
                  onChange={(e) => setAdminOverrideData({ ...adminOverrideData, clockIn: e.target.value })}
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="adminClockOut">Clock Out Time</Label>
                <Input
                  id="adminClockOut"
                  type="time"
                  value={adminOverrideData.clockOut}
                  onChange={(e) => setAdminOverrideData({ ...adminOverrideData, clockOut: e.target.value })}
                />
              </div>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="adminComment">Admin Comment</Label>
              <Textarea
                id="adminComment"
                placeholder="Reason for override"
                value={adminOverrideData.comment}
                onChange={(e) => setAdminOverrideData({ ...adminOverrideData, comment: e.target.value })}
                className="h-20"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAdminOverrideDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleSubmitAdminOverride}>Save Override</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Certification Dialog */}
      <Dialog open={showCertificationDialog} onOpenChange={setShowCertificationDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Time Entry Certification</DialogTitle>
            <DialogDescription>
              Please confirm your time entry by reading and agreeing to the statement below.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <p className="text-sm text-blue-800">
                <strong>Certification Statement:</strong>
              </p>
              <p className="text-sm text-blue-700 mt-2">
                I hereby certify/confirm that the information provided is true and accurate. I also affirm that I used
                the company phone in filling out the form and that the answers were entered and submitted by me and for
                me.
              </p>
            </div>
            <div className="mt-4">
              <p className="text-sm text-gray-600">
                By clicking "Yes, I Confirm", you agree to the certification statement above.
              </p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCertificationDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleCertificationConfirm}>Yes, I Confirm</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
