"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Separator } from "@/components/ui/separator"
import { DollarSign, Download, Calculator, AlertTriangle, FileText, Package } from "lucide-react"

interface EmployeeAllowance {
  id: string
  employeeId: string
  weekStartDate: string
  amount: number
  description: string
}

interface Employee {
  id: string
  name: string
  hourlyRate: number
  position: string
  isActive: boolean
  role: "admin" | "employee"
}

interface TimeEntry {
  id: string
  employeeId: string
  date: string
  clockIn?: string
  clockOut?: string
  hoursWorked: number
  isLate: boolean
  lateMinutes: number
  isAbsent: boolean
  status: "on-time" | "late" | "absent"
}

interface CashAdvance {
  id: string
  employeeId: string
  date: string
  amount: number
  remarks: string
  isPaid: boolean
}

interface Deduction {
  id: string
  name: string
  type: "fixed" | "percentage"
  amount: number
  isActive: boolean
  employeeId?: string
}

interface Schedule {
  id: string
  employeeId: string
  date: string
  dayType: "regular" | "holiday" | "leave"
}

interface PayrollGeneratorProps {
  employees: Employee[]
  timeEntries: TimeEntry[]
  cashAdvances: CashAdvance[]
  deductions?: Deduction[] // Make it optional
  employeeAllowances?: EmployeeAllowance[]
  schedules?: Schedule[]
  onAddCashAdvance: (advance: Omit<CashAdvance, "id">) => void
}

interface PayrollData {
  employeeId: string
  regularHours: number
  overtimeHours: number
  sundayHolidayHours: number
  regularPay: number
  overtimePay: number
  sundayHolidayPay: number
  grossPay: number
  deductions: { name: string; amount: number }[]
  totalDeductions: number
  cashAdvances: number
  allowances: number // Add this line
  latePenalty: number
  netPay: number
  lateCount: number
  absentCount: number
}

export function PayrollGenerator({
  employees,
  timeEntries,
  cashAdvances,
  deductions = [], // Add default empty array
  employeeAllowances = [], // Add default empty array
  schedules,
  onAddCashAdvance,
}: PayrollGeneratorProps) {
  const [selectedPeriod, setSelectedPeriod] = useState("month")
  const [latePenaltyRate, setLatePenaltyRate] = useState("50") // ₱50 per late occurrence
  const pagibigDeduction = 50 // Declare the pagibigDeduction variable

  const getDateRange = () => {
    const today = new Date()
    const startDate = new Date()

    if (selectedPeriod === "week") {
      startDate.setDate(today.getDate() - 7)
    } else if (selectedPeriod === "month") {
      startDate.setMonth(today.getMonth() - 1)
    } else if (selectedPeriod === "biweek") {
      startDate.setDate(today.getDate() - 14)
    }

    return { startDate, endDate: today }
  }

  const { startDate, endDate } = getDateRange()

  const filteredEntries = timeEntries.filter((entry) => {
    const entryDate = new Date(entry.date)
    return entryDate >= startDate && entryDate <= endDate && entry.clockOut
  })

  const calculatePayroll = (): PayrollData[] => {
    const activeEmployees = employees.filter((emp) => emp.isActive && emp.role === "employee")

    return activeEmployees.map((employee) => {
      const employeeEntries = filteredEntries.filter((entry) => entry.employeeId === employee.id)

      // Calculate different types of hours
      let regularHours = 0
      let overtimeHours = 0
      let sundayHolidayHours = 0

      employeeEntries.forEach((entry) => {
        const entryDate = new Date(entry.date)
        const dayOfWeek = entryDate.getDay() // 0 = Sunday, 6 = Saturday
        const isSunday = dayOfWeek === 0

        // Check if it's a holiday from schedule
        const schedule = schedules?.find((s) => s.employeeId === employee.id && s.date === entry.date)
        const isHoliday = schedule?.dayType === "holiday"

        if (isSunday || isHoliday) {
          // Sunday/Holiday work = 125% rate for all hours
          sundayHolidayHours += entry.hoursWorked
        } else {
          // Regular day: first 9 hours = regular, beyond 9 hours = overtime
          if (entry.hoursWorked <= 9) {
            regularHours += entry.hoursWorked
          } else {
            regularHours += 9
            overtimeHours += entry.hoursWorked - 9
          }
        }
      })

      // Calculate pay
      const basicPay = regularHours * employee.hourlyRate // Basic pay for deduction calculations
      const regularPay = regularHours * employee.hourlyRate
      const overtimePay = overtimeHours * employee.hourlyRate * 1.25 // 125% for OT
      const sundayHolidayPay = sundayHolidayHours * employee.hourlyRate * 1.25 // 125% for Sunday/Holiday

      const grossPay = regularPay + overtimePay + sundayHolidayPay

      // Calculate mandatory deductions based on basic pay - only on last day of week
      // Check if we're at the end of the week (Sunday) to apply Pag-IBIG
      const isEndOfWeek = employeeEntries.some((entry) => {
        const entryDate = new Date(entry.date)
        return entryDate.getDay() === 0 // Sunday
      })

      const standardDeductions = [
        { name: "SSS", amount: basicPay * 0.05 }, // 5% of basic pay
        { name: "PhilHealth", amount: basicPay * 0.025 }, // 2.5% of basic pay
        { name: "Pag-IBIG", amount: isEndOfWeek ? pagibigDeduction : 0 }, // ₱50 only at end of week
      ].filter((deduction) => deduction.amount > 0) // Remove zero amounts

      // Add custom employee deductions (but exclude the standard ones to avoid duplication)
      const customDeductions = (deductions || [])
        .filter(
          (deduction) =>
            deduction.employeeId === employee.id &&
            deduction.isActive &&
            !["SSS", "PhilHealth", "Pag-IBIG"].includes(deduction.name),
        )
        .map((deduction) => {
          const baseAmount = deduction.type === "fixed" ? deduction.amount : (basicPay * deduction.amount) / 100
          const cashAdvance = deduction.cashAdvanceAmount || 0
          return {
            name: deduction.name,
            amount: baseAmount,
            cashAdvance: cashAdvance,
          }
        })

      const allDeductions = [...standardDeductions, ...customDeductions]
      const totalDeductions = allDeductions.reduce((sum, deduction) => sum + deduction.amount, 0)

      // Calculate total cash advances from deductions
      const totalCashAdvances = customDeductions.reduce((sum, deduction) => sum + (deduction.cashAdvance || 0), 0)

      // Calculate allowances for the period
      const employeeAllowancesForPeriod = employeeAllowances
        .filter((allowance) => {
          const allowanceWeekStart = new Date(allowance.weekStartDate)
          return (
            allowance.employeeId === employee.id && allowanceWeekStart >= startDate && allowanceWeekStart <= endDate
          )
        })
        .reduce((sum, allowance) => sum + allowance.amount, 0)

      // Calculate late penalty
      const lateCount = employeeEntries.filter((entry) => entry.isLate).length
      const absentCount = employeeEntries.filter((entry) => entry.isAbsent).length
      const latePenalty = lateCount * Number.parseFloat(latePenaltyRate)

      const netPay = grossPay - totalDeductions - totalCashAdvances - latePenalty + employeeAllowancesForPeriod

      return {
        employeeId: employee.id,
        regularHours,
        overtimeHours,
        sundayHolidayHours,
        regularPay,
        overtimePay,
        sundayHolidayPay,
        grossPay,
        deductions: allDeductions,
        totalDeductions,
        cashAdvances: totalCashAdvances, // Use cash advances from deductions
        allowances: employeeAllowancesForPeriod,
        latePenalty,
        netPay: grossPay - totalDeductions - totalCashAdvances - latePenalty + employeeAllowancesForPeriod,
        lateCount,
        absentCount,
      }
    })
  }

  const payrollData = calculatePayroll()
  const totalPayroll = payrollData.reduce((sum, data) => sum + data.netPay, 0)
  const totalHours = payrollData.reduce((sum, data) => sum + data.regularHours + data.overtimeHours, 0)
  const totalDeductions = payrollData.reduce((sum, data) => sum + data.totalDeductions, 0)

  const exportPayroll = () => {
    const csvContent = [
      [
        "Employee",
        "Position",
        "Regular Hours",
        "Overtime Hours",
        "Hourly Rate",
        "Regular Pay",
        "Overtime Pay",
        "Gross Pay",
        "SSS",
        "PhilHealth",
        "Pag-IBIG",
        "Other Deductions",
        "Cash Advance",
        "Late Penalty",
        "Total Deductions & Advances",
        "Net Pay",
        "Late Count",
        "Absent Count",
      ],
      ...payrollData.map((data) => {
        const employee = employees.find((emp) => emp.id === data.employeeId)!
        const sss = data.deductions.find((d) => d.name === "SSS")?.amount || 0
        const philhealth = data.deductions.find((d) => d.name === "PhilHealth")?.amount || 0
        const pagibig = data.deductions.find((d) => d.name === "Pag-IBIG")?.amount || 0
        const otherDeductions = data.deductions
          .filter((d) => !["SSS", "PhilHealth", "Pag-IBIG"].includes(d.name))
          .reduce((sum, d) => sum + d.amount, 0)
        return [
          employee.name,
          employee.position,
          data.regularHours.toFixed(2),
          data.overtimeHours.toFixed(2),
          employee.hourlyRate.toFixed(2),
          data.regularPay.toFixed(2),
          data.overtimePay.toFixed(2),
          data.grossPay.toFixed(2),
          sss.toFixed(2),
          philhealth.toFixed(2),
          pagibig.toFixed(2),
          otherDeductions.toFixed(2),
          data.cashAdvances.toFixed(2),
          data.latePenalty.toFixed(2),
          (data.totalDeductions + data.cashAdvances + data.latePenalty).toFixed(2),
          data.netPay.toFixed(2),
          data.lateCount.toString(),
          data.absentCount.toString(),
        ]
      }),
    ]
      .map((row) => row.join(","))
      .join("\n")

    const blob = new Blob([csvContent], { type: "text/csv" })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `payroll-${selectedPeriod}-${new Date().toISOString().split("T")[0]}.csv`
    a.click()
    window.URL.revokeObjectURL(url)
  }

  const generatePayslipPDF = (employeeData: PayrollData) => {
    const employee = employees.find((emp) => emp.id === employeeData.employeeId)!
    const employeeEntries = filteredEntries.filter((entry) => entry.employeeId === employee.id)

    // Calculate daily breakdown
    const dailyBreakdown = employeeEntries.map((entry) => {
      const entryDate = new Date(entry.date)
      const dayOfWeek = entryDate.getDay()
      const isSunday = dayOfWeek === 0
      const schedule = schedules?.find((s) => s.employeeId === employee.id && s.date === entry.date)
      const isHoliday = schedule?.dayType === "holiday"

      let regularHours = 0
      let overtimeHours = 0
      let sundayHolidayHours = 0

      if (isSunday || isHoliday) {
        sundayHolidayHours = entry.hoursWorked
      } else {
        if (entry.hoursWorked <= 9) {
          regularHours = entry.hoursWorked
        } else {
          regularHours = 9
          overtimeHours = entry.hoursWorked - 9
        }
      }

      const regularPay = regularHours * employee.hourlyRate
      const overtimePay = overtimeHours * employee.hourlyRate * 1.25
      const sundayHolidayPay = sundayHolidayHours * employee.hourlyRate * 1.25
      const totalDayPay = regularPay + overtimePay + sundayHolidayPay

      return {
        date: entry.date,
        clockIn: entry.clockIn,
        clockOut: entry.clockOut,
        totalHours: entry.hoursWorked,
        regularHours,
        overtimeHours,
        sundayHolidayHours,
        regularPay,
        overtimePay,
        sundayHolidayPay,
        totalDayPay,
        dayType: isSunday ? "Sunday" : isHoliday ? "Holiday" : "Regular",
        status: entry.status,
      }
    })

    const payslipContent = `
DETAILED PAYSLIP - ${employee.name}
Period: ${startDate.toLocaleDateString()} - ${endDate.toLocaleDateString()}
Position: ${employee.position}
Hourly Rate: ₱${employee.hourlyRate.toFixed(2)}

DAILY BREAKDOWN:
${dailyBreakdown
  .map(
    (day) => `
Date: ${new Date(day.date).toLocaleDateString()} (${day.dayType})
Time: ${day.clockIn || "N/A"} - ${day.clockOut || "N/A"}
Hours: ${day.totalHours.toFixed(1)}h (Regular: ${day.regularHours.toFixed(1)}h, OT: ${day.overtimeHours.toFixed(1)}h, Holiday/Sunday: ${day.sundayHolidayHours.toFixed(1)}h)
Pay: ₱${day.totalDayPay.toFixed(2)} (Regular: ₱${day.regularPay.toFixed(2)}, OT: ₱${day.overtimePay.toFixed(2)}, Holiday/Sunday: ₱${day.sundayHolidayPay.toFixed(2)})
Status: ${day.status}
`,
  )
  .join("")}

SUMMARY:
Total Regular Hours: ${employeeData.regularHours.toFixed(1)} @ ₱${employee.hourlyRate}/hr = ₱${employeeData.regularPay.toFixed(2)}
Total Overtime Hours: ${employeeData.overtimeHours.toFixed(1)} @ ₱${(employee.hourlyRate * 1.25).toFixed(2)}/hr = ₱${employeeData.overtimePay.toFixed(2)}
Total Sunday/Holiday Hours: ${employeeData.sundayHolidayHours.toFixed(1)} @ ₱${(employee.hourlyRate * 1.25).toFixed(2)}/hr = ₱${employeeData.sundayHolidayPay.toFixed(2)}

GROSS PAY: ₱${employeeData.grossPay.toFixed(2)}

DEDUCTIONS (Applied on last day of week):
${employeeData.deductions.map((d) => `${d.name}: ₱${d.amount.toFixed(2)}`).join("\n")}
${employeeData.cashAdvances > 0 ? `Cash Advance: ₱${employeeData.cashAdvances.toFixed(2)}` : ""}
${employeeData.latePenalty > 0 ? `Late Penalty: ₱${employeeData.latePenalty.toFixed(2)} (${employeeData.lateCount} late days)` : ""}

ALLOWANCES:
${employeeData.allowances > 0 ? `Weekly Allowances: ₱${employeeData.allowances.toFixed(2)}` : "No allowances"}

TOTAL DEDUCTIONS: ₱${(employeeData.totalDeductions + employeeData.cashAdvances + employeeData.latePenalty).toFixed(2)}

NET PAY: ₱${employeeData.netPay.toFixed(2)}

Basic Pay (for deduction calculation): ₱${(employeeData.regularHours * employee.hourlyRate).toFixed(2)}
`

    const blob = new Blob([payslipContent], { type: "text/plain" })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `detailed-payslip-${employee.name.replace(/\s+/g, "-")}-${new Date().toISOString().split("T")[0]}.txt`
    a.click()
    window.URL.revokeObjectURL(url)
  }

  // Function to export all payslips as a zip file
  const exportAllPayslips = async () => {
    try {
      // Create a zip file using JSZip (we'll simulate this with multiple downloads)
      const zipFiles = []

      for (const data of payrollData) {
        const employee = employees.find((emp) => emp.id === data.employeeId)!
        const employeeEntries = filteredEntries.filter((entry) => entry.employeeId === employee.id)

        // Calculate daily breakdown
        const dailyBreakdown = employeeEntries.map((entry) => {
          const entryDate = new Date(entry.date)
          const dayOfWeek = entryDate.getDay()
          const isSunday = dayOfWeek === 0
          const schedule = schedules?.find((s) => s.employeeId === employee.id && s.date === entry.date)
          const isHoliday = schedule?.dayType === "holiday"

          let regularHours = 0
          let overtimeHours = 0
          let sundayHolidayHours = 0

          if (isSunday || isHoliday) {
            sundayHolidayHours = entry.hoursWorked
          } else {
            if (entry.hoursWorked <= 9) {
              regularHours = entry.hoursWorked
            } else {
              regularHours = 9
              overtimeHours = entry.hoursWorked - 9
            }
          }

          const regularPay = regularHours * employee.hourlyRate
          const overtimePay = overtimeHours * employee.hourlyRate * 1.25
          const sundayHolidayPay = sundayHolidayHours * employee.hourlyRate * 1.25
          const totalDayPay = regularPay + overtimePay + sundayHolidayPay

          return {
            date: entry.date,
            clockIn: entry.clockIn,
            clockOut: entry.clockOut,
            totalHours: entry.hoursWorked,
            regularHours,
            overtimeHours,
            sundayHolidayHours,
            regularPay,
            overtimePay,
            sundayHolidayPay,
            totalDayPay,
            dayType: isSunday ? "Sunday" : isHoliday ? "Holiday" : "Regular",
            status: entry.status,
          }
        })

        const payslipContent = `
DETAILED PAYSLIP - ${employee.name}
Period: ${startDate.toLocaleDateString()} - ${endDate.toLocaleDateString()}
Position: ${employee.position}
Hourly Rate: ₱${employee.hourlyRate.toFixed(2)}

DAILY BREAKDOWN:
${dailyBreakdown
  .map(
    (day) => `
Date: ${new Date(day.date).toLocaleDateString()} (${day.dayType})
Time: ${day.clockIn || "N/A"} - ${day.clockOut || "N/A"}
Hours: ${day.totalHours.toFixed(1)}h (Regular: ${day.regularHours.toFixed(1)}h, OT: ${day.overtimeHours.toFixed(1)}h, Holiday/Sunday: ${day.sundayHolidayHours.toFixed(1)}h)
Pay: ₱${day.totalDayPay.toFixed(2)} (Regular: ₱${day.regularPay.toFixed(2)}, OT: ₱${day.overtimePay.toFixed(2)}, Holiday/Sunday: ₱${day.sundayHolidayPay.toFixed(2)})
Status: ${day.status}
`,
  )
  .join("")}

SUMMARY:
Total Regular Hours: ${data.regularHours.toFixed(1)} @ ₱${employee.hourlyRate}/hr = ₱${data.regularPay.toFixed(2)}
Total Overtime Hours: ${data.overtimeHours.toFixed(1)} @ ₱${(employee.hourlyRate * 1.25).toFixed(2)}/hr = ₱${data.overtimePay.toFixed(2)}
Total Sunday/Holiday Hours: ${data.sundayHolidayHours.toFixed(1)} @ ₱${(employee.hourlyRate * 1.25).toFixed(2)}/hr = ₱${data.sundayHolidayPay.toFixed(2)}

GROSS PAY: ₱${data.grossPay.toFixed(2)}

DEDUCTIONS (Applied on last day of week):
${data.deductions.map((d) => `${d.name}: ₱${d.amount.toFixed(2)}`).join("\n")}
${data.cashAdvances > 0 ? `Cash Advance: ₱${data.cashAdvances.toFixed(2)}` : ""}
${data.latePenalty > 0 ? `Late Penalty: ₱${data.latePenalty.toFixed(2)} (${data.lateCount} late days)` : ""}

ALLOWANCES:
${data.allowances > 0 ? `Weekly Allowances: ₱${data.allowances.toFixed(2)}` : "No allowances"}

TOTAL DEDUCTIONS: ₱${(data.totalDeductions + data.cashAdvances + data.latePenalty).toFixed(2)}

NET PAY: ₱${data.netPay.toFixed(2)}

Basic Pay (for deduction calculation): ₱${(data.regularHours * employee.hourlyRate).toFixed(2)}
`

        zipFiles.push({
          filename: `payslip-${employee.name.replace(/\s+/g, "-")}.txt`,
          content: payslipContent,
        })
      }

      // Since we can't use JSZip in this environment, we'll create a combined file
      const combinedContent = zipFiles
        .map((file) => `=== ${file.filename} ===\n${file.content}\n\n`)
        .join("\n" + "=".repeat(80) + "\n\n")

      const blob = new Blob([combinedContent], { type: "text/plain" })
      const url = window.URL.createObjectURL(blob)
      const a = document.createElement("a")
      a.href = url
      a.download = `all-payslips-${selectedPeriod}-${new Date().toISOString().split("T")[0]}.txt`
      a.click()
      window.URL.revokeObjectURL(url)

      alert(`Successfully exported ${payrollData.length} payslips in a combined file!`)
    } catch (error) {
      console.error("Error exporting payslips:", error)
      alert("Error exporting payslips. Please try again.")
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold text-gray-900">Payroll Generator</h2>
          <p className="text-gray-600">Calculate and export employee payroll (Philippine Peso)</p>
        </div>
        <div className="flex items-center space-x-4">
          <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="week">Last Week</SelectItem>
              <SelectItem value="biweek">Last 2 Weeks</SelectItem>
              <SelectItem value="month">Last Month</SelectItem>
            </SelectContent>
          </Select>
          <Select value={latePenaltyRate} onValueChange={setLatePenaltyRate}>
            <SelectTrigger className="w-48">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="0">No Late Penalty</SelectItem>
              <SelectItem value="50">₱50 per Late Day</SelectItem>
              <SelectItem value="100">₱100 per Late Day</SelectItem>
              <SelectItem value="150">₱150 per Late Day</SelectItem>
            </SelectContent>
          </Select>
          <Button onClick={exportPayroll} variant="outline" className="flex items-center space-x-2">
            <Download className="h-4 w-4" />
            <span>Export CSV</span>
          </Button>
          <Button onClick={exportAllPayslips} className="flex items-center space-x-2">
            <Package className="h-4 w-4" />
            <span>Export All Payslips</span>
          </Button>
        </div>
      </div>

      {/* Payroll Summary */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Payroll</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">₱{totalPayroll.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">Net pay after deductions</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Hours</CardTitle>
            <Calculator className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalHours.toFixed(1)}</div>
            <p className="text-xs text-muted-foreground">All employees combined</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Overtime Hours</CardTitle>
            <Calculator className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {payrollData.reduce((sum, data) => sum + data.overtimeHours, 0).toFixed(1)}
            </div>
            <p className="text-xs text-muted-foreground">At 125% rate</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Deductions</CardTitle>
            <AlertTriangle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">₱{totalDeductions.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">SSS, PhilHealth, Pag-IBIG (applied on last day)</p>
          </CardContent>
        </Card>
      </div>

      {/* Individual Payroll Breakdown */}
      <Card>
        <CardHeader>
          <CardTitle>Employee Payroll Breakdown</CardTitle>
          <CardDescription>
            Detailed pay calculation for each employee ({selectedPeriod}) - Deductions applied on last day of week
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {payrollData.map((data) => {
              const employee = employees.find((emp) => emp.id === data.employeeId)!
              const employeeEntries = filteredEntries.filter((entry) => entry.employeeId === employee.id)

              return (
                <div key={employee.id} className="p-6 border rounded-lg">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center space-x-3">
                      <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                        <span className="text-blue-600 font-semibold">
                          {employee.name
                            .split(" ")
                            .map((n) => n[0])
                            .join("")}
                        </span>
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold">{employee.name}</h3>
                        <p className="text-gray-600">
                          {employee.position} • ₱{employee.hourlyRate.toFixed(2)}/hour
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="text-right">
                        <p className="text-2xl font-bold text-green-600">₱{data.netPay.toFixed(2)}</p>
                        <p className="text-sm text-gray-500">Net Pay</p>
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => generatePayslipPDF(data)}
                        className="flex items-center space-x-1"
                      >
                        <FileText className="h-4 w-4" />
                        <span>Payslip</span>
                      </Button>
                    </div>
                  </div>

                  {/* Earnings Section */}
                  <div className="mb-4">
                    <h4 className="font-semibold mb-2 text-green-700">EARNINGS</h4>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                      <div>
                        <p className="text-gray-500">Regular Hours</p>
                        <p className="font-semibold">{data.regularHours.toFixed(1)}</p>
                      </div>
                      <div>
                        <p className="text-gray-500">Overtime Hours</p>
                        <p className="font-semibold">{data.overtimeHours.toFixed(1)}</p>
                      </div>
                      <div>
                        <p className="text-gray-500">Regular Pay</p>
                        <p className="font-semibold">₱{data.regularPay.toFixed(2)}</p>
                      </div>
                      <div>
                        <p className="text-gray-500">Overtime Pay</p>
                        <p className="font-semibold">₱{data.overtimePay.toFixed(2)}</p>
                      </div>
                    </div>
                    <div className="mt-2 pt-2 border-t">
                      <div className="flex justify-between">
                        <span className="font-semibold">Gross Pay:</span>
                        <span className="font-semibold">₱{data.grossPay.toFixed(2)}</span>
                      </div>
                    </div>
                  </div>

                  <Separator className="my-4" />

                  {/* Deductions Section */}
                  <div className="mb-4">
                    <h4 className="font-semibold mb-2 text-red-700">
                      DEDUCTIONS & CASH ADVANCES (Applied on Last Day of Week)
                    </h4>
                    <div className="space-y-2 text-sm">
                      {data.deductions.map((deduction) => (
                        <div key={deduction.name} className="flex justify-between">
                          <span className="text-gray-600">- {deduction.name}</span>
                          <span className="text-red-600">₱{deduction.amount.toFixed(2)}</span>
                        </div>
                      ))}
                      {data.cashAdvances > 0 && (
                        <div className="flex justify-between">
                          <span className="text-gray-600">- Cash Advance</span>
                          <span className="text-red-600">₱{data.cashAdvances.toFixed(2)}</span>
                        </div>
                      )}
                      {data.latePenalty > 0 && (
                        <div className="flex justify-between">
                          <span className="text-gray-600">- Late Penalty ({data.lateCount} days)</span>
                          <span className="text-red-600">₱{data.latePenalty.toFixed(2)}</span>
                        </div>
                      )}
                    </div>
                  </div>

                  <Separator className="my-4" />

                  {/* Summary */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                    <div>
                      <p className="text-gray-500">Days Worked</p>
                      <p className="font-semibold">{employeeEntries.length}</p>
                    </div>
                    <div>
                      <p className="text-gray-500">Late Days</p>
                      <p className="font-semibold text-red-600">{data.lateCount}</p>
                    </div>
                    <div>
                      <p className="text-gray-500">Absent Days</p>
                      <p className="font-semibold text-red-600">{data.absentCount}</p>
                    </div>
                    <div>
                      <p className="text-gray-500">Total Deductions</p>
                      <p className="font-semibold text-red-600">
                        ₱{(data.totalDeductions + data.cashAdvances + data.latePenalty).toFixed(2)}
                      </p>
                    </div>
                  </div>

                  {data.overtimeHours > 0 && (
                    <div className="mt-3 p-2 bg-yellow-50 border border-yellow-200 rounded text-sm text-yellow-800">
                      <div className="flex items-center space-x-1">
                        <AlertTriangle className="h-4 w-4" />
                        <span>
                          Overtime: {data.overtimeHours.toFixed(1)} hours at 125% rate (₱
                          {(employee.hourlyRate * 1.25).toFixed(2)}/hr)
                        </span>
                      </div>
                    </div>
                  )}

                  {(data.lateCount > 0 || data.absentCount > 0) && (
                    <div className="mt-2 p-2 bg-red-50 border border-red-200 rounded text-sm text-red-800">
                      <div className="flex items-center space-x-1">
                        <AlertTriangle className="h-4 w-4" />
                        <span>
                          Attendance Issues: {data.lateCount} late arrival(s), {data.absentCount} absent day(s)
                        </span>
                      </div>
                    </div>
                  )}
                </div>
              )
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
