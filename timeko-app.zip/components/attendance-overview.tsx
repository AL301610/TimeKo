"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Calendar, Clock, AlertCircle, TrendingUp } from "lucide-react"

interface Employee {
  id: string
  name: string
  hourlyRate: number
  position: string
  isActive: boolean
  role: "admin" | "employee"
}

interface TimeEntry {
  id: string
  employeeId: string
  date: string
  clockIn?: string
  clockOut?: string
  hoursWorked: number
  isLate: boolean
  lateMinutes: number
  isAbsent: boolean
  status: "on-time" | "late" | "absent"
}

interface Schedule {
  id: string
  employeeId: string
  date: string
  startTime: string
  endTime: string
  dayType: "regular" | "sunday" | "holiday"
  isRestDay: boolean
}

interface AttendanceOverviewProps {
  employees: Employee[]
  timeEntries: TimeEntry[]
  schedules: Schedule[]
}

export function AttendanceOverview({ employees, timeEntries, schedules }: AttendanceOverviewProps) {
  const [selectedPeriod, setSelectedPeriod] = useState("week")
  const [selectedEmployee, setSelectedEmployee] = useState("all")

  const getDateRange = () => {
    const today = new Date()
    const startDate = new Date()

    if (selectedPeriod === "week") {
      startDate.setDate(today.getDate() - 7)
    } else if (selectedPeriod === "month") {
      startDate.setMonth(today.getMonth() - 1)
    }

    return { startDate, endDate: today }
  }

  const { startDate, endDate } = getDateRange()

  const filteredEntries = timeEntries.filter((entry) => {
    const entryDate = new Date(entry.date)
    const inRange = entryDate >= startDate && entryDate <= endDate
    const matchesEmployee = selectedEmployee === "all" || entry.employeeId === selectedEmployee
    return inRange && matchesEmployee
  })

  const getEmployeeStats = (employeeId: string) => {
    const employeeEntries = filteredEntries.filter((entry) => entry.employeeId === employeeId)
    const employeeSchedules = schedules.filter((schedule) => {
      const scheduleDate = new Date(schedule.date)
      return schedule.employeeId === employeeId && scheduleDate >= startDate && scheduleDate <= endDate
    })

    const totalHours = employeeEntries.reduce((sum, entry) => sum + entry.hoursWorked, 0)
    const scheduledDays = employeeSchedules.length
    const workedDays = employeeEntries.filter((entry) => entry.clockIn && entry.clockOut).length
    const lateDays = employeeEntries.filter((entry) => entry.isLate).length
    const absentDays = employeeSchedules.length - workedDays
    const totalLateMinutes = employeeEntries.reduce((sum, entry) => sum + entry.lateMinutes, 0)

    return {
      totalHours,
      scheduledDays,
      workedDays,
      lateDays,
      absentDays,
      totalLateMinutes,
      averageHours: workedDays > 0 ? totalHours / workedDays : 0,
      attendanceRate: scheduledDays > 0 ? (workedDays / scheduledDays) * 100 : 100,
      punctualityRate: workedDays > 0 ? ((workedDays - lateDays) / workedDays) * 100 : 100,
    }
  }

  const activeEmployees = employees.filter((emp) => emp.isActive && emp.role === "employee")

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold text-gray-900">Attendance Overview</h2>
          <p className="text-gray-600">Track employee attendance and punctuality</p>
        </div>
        <div className="flex items-center space-x-4">
          <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="week">Last Week</SelectItem>
              <SelectItem value="month">Last Month</SelectItem>
            </SelectContent>
          </Select>
          <Select value={selectedEmployee} onValueChange={setSelectedEmployee}>
            <SelectTrigger className="w-48">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Employees</SelectItem>
              {activeEmployees.map((employee) => (
                <SelectItem key={employee.id} value={employee.id}>
                  {employee.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Summary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Hours</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {filteredEntries.reduce((sum, entry) => sum + entry.hoursWorked, 0).toFixed(1)}
            </div>
            <p className="text-xs text-muted-foreground">Across all employees</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Worked Days</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {filteredEntries.filter((entry) => entry.clockIn && entry.clockOut).length}
            </div>
            <p className="text-xs text-muted-foreground">Completed shifts</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Late Arrivals</CardTitle>
            <AlertCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{filteredEntries.filter((entry) => entry.isLate).length}</div>
            <p className="text-xs text-muted-foreground">
              {(
                (filteredEntries.filter((entry) => entry.isLate).length / Math.max(filteredEntries.length, 1)) *
                100
              ).toFixed(1)}
              % of shifts
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg Hours/Day</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {(
                filteredEntries.reduce((sum, entry) => sum + entry.hoursWorked, 0) / Math.max(filteredEntries.length, 1)
              ).toFixed(1)}
            </div>
            <p className="text-xs text-muted-foreground">Per shift average</p>
          </CardContent>
        </Card>
      </div>

      {/* Employee Breakdown */}
      <Card>
        <CardHeader>
          <CardTitle>Employee Attendance Breakdown</CardTitle>
          <CardDescription>Individual performance for the selected period</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {activeEmployees.map((employee) => {
              const stats = getEmployeeStats(employee.id)

              return (
                <div key={employee.id} className="p-4 border rounded-lg">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                        <span className="text-blue-600 font-semibold">
                          {employee.name
                            .split(" ")
                            .map((n) => n[0])
                            .join("")}
                        </span>
                      </div>
                      <div>
                        <h3 className="font-semibold">{employee.name}</h3>
                        <p className="text-sm text-gray-600">
                          {employee.position} • ₱{employee.hourlyRate}/hr
                        </p>
                      </div>
                    </div>
                    <div className="flex space-x-2">
                      <Badge
                        variant={
                          stats.attendanceRate >= 95
                            ? "default"
                            : stats.attendanceRate >= 85
                              ? "secondary"
                              : "destructive"
                        }
                      >
                        {stats.attendanceRate.toFixed(0)}% Attendance
                      </Badge>
                      <Badge
                        variant={
                          stats.punctualityRate >= 90
                            ? "default"
                            : stats.punctualityRate >= 75
                              ? "secondary"
                              : "destructive"
                        }
                      >
                        {stats.punctualityRate.toFixed(0)}% On Time
                      </Badge>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-5 gap-4 text-sm">
                    <div>
                      <p className="text-gray-500">Total Hours</p>
                      <p className="font-semibold">{stats.totalHours.toFixed(1)}</p>
                    </div>
                    <div>
                      <p className="text-gray-500">Scheduled Days</p>
                      <p className="font-semibold">{stats.scheduledDays}</p>
                    </div>
                    <div>
                      <p className="text-gray-500">Worked Days</p>
                      <p className="font-semibold text-green-600">{stats.workedDays}</p>
                    </div>
                    <div>
                      <p className="text-gray-500">Late Days</p>
                      <p className="font-semibold text-red-600">{stats.lateDays}</p>
                    </div>
                    <div>
                      <p className="text-gray-500">Absent Days</p>
                      <p className="font-semibold text-red-600">{stats.absentDays}</p>
                    </div>
                  </div>

                  {stats.totalLateMinutes > 0 && (
                    <div className="mt-2 text-sm text-red-600">Total late time: {stats.totalLateMinutes} minutes</div>
                  )}

                  <div className="mt-2 text-sm text-gray-600">
                    Average hours per working day: {stats.averageHours.toFixed(1)} hours
                  </div>
                </div>
              )
            })}
          </div>
        </CardContent>
      </Card>

      {/* Recent Entries */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Time Entries</CardTitle>
          <CardDescription>Latest clock-ins and clock-outs</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {filteredEntries
              .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
              .slice(0, 10)
              .map((entry) => {
                const employee = employees.find((emp) => emp.id === entry.employeeId)
                if (!employee) return null

                return (
                  <div key={entry.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                        <span className="text-blue-600 font-semibold text-sm">
                          {employee.name
                            .split(" ")
                            .map((n) => n[0])
                            .join("")}
                        </span>
                      </div>
                      <div>
                        <p className="font-medium">{employee.name}</p>
                        <p className="text-sm text-gray-500">{new Date(entry.date).toLocaleDateString()}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="flex items-center space-x-2">
                        <span className="text-sm">
                          {entry.clockIn || "No clock in"} - {entry.clockOut || "Working"}
                        </span>
                        <Badge
                          variant={
                            entry.status === "on-time"
                              ? "default"
                              : entry.status === "late"
                                ? "destructive"
                                : "secondary"
                          }
                        >
                          {entry.status}
                        </Badge>
                      </div>
                      <p className="text-xs text-gray-500">
                        {entry.hoursWorked.toFixed(1)} hours • ₱{(entry.hoursWorked * employee.hourlyRate).toFixed(2)}
                      </p>
                    </div>
                  </div>
                )
              })}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
