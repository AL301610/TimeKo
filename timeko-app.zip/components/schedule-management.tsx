"use client"

import type React from "react"
import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Calendar,
  Plus,
  Clock,
  Users,
  Upload,
  Download,
  RefreshCw,
  AlertTriangle,
  CheckCircle,
  Eye,
} from "lucide-react"

interface User {
  id: string
  name: string
  role: "admin" | "employee"
  employeeId?: string
}

interface Employee {
  id: string
  name: string
  position: string
  role: "admin" | "employee"
}

interface Schedule {
  id: string
  employeeId: string
  date: string
  startTime: string
  endTime: string
  dayType: "regular" | "sunday" | "holiday"
  isRestDay: boolean
  isActive?: boolean
}

interface CompanySettings {
  name: string
  address: string
  logoUrl?: string
  headerUrl?: string
}

interface ScheduleManagementProps {
  currentUser: User
  employees: Employee[]
  schedules: Schedule[]
  companySettings: CompanySettings
  onAddSchedule: (schedule: Omit<Schedule, "id">) => void
  onUpdateSchedule: (id: string, updates: Partial<Schedule>) => void
  onImportSchedules: (schedules: any[]) => void
}

export function ScheduleManagement({
  currentUser,
  employees,
  schedules,
  companySettings,
  onAddSchedule,
  onUpdateSchedule,
  onImportSchedules,
}: ScheduleManagementProps) {
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isPreviewDialogOpen, setIsPreviewDialogOpen] = useState(false)
  const [selectedWeek, setSelectedWeek] = useState(getWeekStart(new Date()))
  const [formData, setFormData] = useState({
    employeeId: "",
    date: "",
    startTime: "09:00",
    endTime: "18:00",
    dayType: "regular" as "regular" | "sunday" | "holiday",
    isRestDay: false,
  })
  const [editingSchedule, setEditingSchedule] = useState<Schedule | null>(null)
  const [importStatus, setImportStatus] = useState<string | null>(null)
  const [refreshKey, setRefreshKey] = useState(0)

  const isAdmin = currentUser.role === "admin"
  const currentEmployee = employees.find((emp) => emp.id === currentUser.employeeId || emp.email === currentUser.email)

  const activeEmployees = employees.filter((emp) => emp.role === "employee")

  function getWeekStart(date: Date) {
    const d = new Date(date)
    const day = d.getDay()
    const diff = d.getDate() - day + (day === 0 ? -6 : 1) // Start from Monday
    return new Date(d.setDate(diff)).toISOString().split("T")[0]
  }

  function getWeekDates(weekStart: string) {
    const dates = []
    const start = new Date(weekStart)
    for (let i = 0; i < 7; i++) {
      const date = new Date(start)
      date.setDate(start.getDate() + i)
      dates.push(date.toISOString().split("T")[0])
    }
    return dates
  }

  const weekDates = getWeekDates(selectedWeek)
  const dayNames = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]

  const getScheduleForDay = (employeeId: string, date: string) => {
    return schedules.find(
      (schedule) => schedule.employeeId === employeeId && schedule.date === date && schedule.isActive !== false,
    )
  }

  const handleEditSchedule = (schedule: Schedule) => {
    setEditingSchedule(schedule)
    setFormData({
      employeeId: schedule.employeeId,
      date: schedule.date,
      startTime: schedule.startTime,
      endTime: schedule.endTime,
      dayType: schedule.dayType,
      isRestDay: schedule.isRestDay,
    })
  }

  const handleDeleteSchedule = (scheduleId: string) => {
    if (confirm("Are you sure you want to delete this schedule entry?")) {
      onUpdateSchedule(scheduleId, { isActive: false }) // Soft delete
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (editingSchedule) {
      onUpdateSchedule(editingSchedule.id, {
        employeeId: formData.employeeId,
        date: formData.date,
        startTime: formData.startTime,
        endTime: formData.endTime,
        dayType: formData.dayType,
        isRestDay: formData.isRestDay,
      })
      setEditingSchedule(null)
    } else {
      onAddSchedule({
        employeeId: formData.employeeId,
        date: formData.date,
        startTime: formData.startTime,
        endTime: formData.endTime,
        dayType: formData.dayType,
        isRestDay: formData.isRestDay,
      })
      setIsAddDialogOpen(false)
    }
    setFormData({
      employeeId: "",
      date: "",
      startTime: "09:00",
      endTime: "18:00",
      dayType: "regular",
      isRestDay: false,
    })
    setRefreshKey((prev) => prev + 1)
  }

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) {
      setImportStatus("No file selected")
      return
    }

    setImportStatus("Processing file...")

    const reader = new FileReader()
    reader.onload = (e) => {
      try {
        const text = e.target?.result as string
        const lines = text.split("\n")

        if (lines.length < 2) {
          setImportStatus("File is empty or has no data rows")
          return
        }

        const headers = lines[0].split(",").map((h) => h.trim())

        if (headers.length < 5) {
          setImportStatus("Invalid CSV format. Missing required columns")
          return
        }

        const newSchedules = []
        const errors = []

        for (let i = 1; i < lines.length; i++) {
          const line = lines[i].trim()
          if (!line) continue

          const values = line.split(",").map((v) => v.trim().replace(/"/g, "")) // Remove quotes

          if (values.length < 5) {
            errors.push(`Line ${i + 1}: Not enough columns`)
            continue
          }

          const employeeName = values[0]
          const employee = employees.find((emp) => emp.name === employeeName)

          if (!employee) {
            errors.push(`Line ${i + 1}: Employee "${employeeName}" not found`)
            continue
          }

          const date = values[1]
          if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) {
            errors.push(`Line ${i + 1}: Invalid date format "${date}". Use YYYY-MM-DD`)
            continue
          }

          const startTime = values[2]
          const endTime = values[3]
          if (!/^\d{1,2}:\d{2}$/.test(startTime) || !/^\d{1,2}:\d{2}$/.test(endTime)) {
            errors.push(`Line ${i + 1}: Invalid time format. Use HH:MM`)
            continue
          }

          const dayType = values[4].toLowerCase()
          if (!["regular", "sunday", "holiday"].includes(dayType)) {
            errors.push(`Line ${i + 1}: Invalid day type "${dayType}". Use regular, sunday, or holiday`)
            continue
          }

          const isRestDay = values[5]?.toLowerCase() === "true"

          newSchedules.push({
            employeeId: employee.id,
            date,
            startTime,
            endTime,
            dayType: dayType as "regular" | "sunday" | "holiday",
            isRestDay,
          })
        }

        if (errors.length > 0) {
          setImportStatus(
            `Imported with ${errors.length} errors:\n${errors.slice(0, 3).join("\n")}${errors.length > 3 ? `\n...and ${errors.length - 3} more` : ""}`,
          )
        }

        if (newSchedules.length > 0) {
          onImportSchedules(newSchedules)
          setImportStatus(
            `Successfully imported ${newSchedules.length} schedule entries${errors.length > 0 ? ` with ${errors.length} errors` : ""}`,
          )
          // Force refresh after import
          setRefreshKey((prev) => prev + 1)
        } else {
          setImportStatus("No valid schedule entries found. Please check the format.")
        }
      } catch (error) {
        console.error("Import error:", error)
        setImportStatus(`Error reading file: ${error instanceof Error ? error.message : "Unknown error"}`)
      }
    }
    reader.readAsText(file)
  }

  const exportTemplate = () => {
    const csvContent = [
      ["Employee Name", "Date", "Start Time", "End Time", "Day Type", "Is Rest Day"],
      ["Maria Santos", "2024-01-15", "09:00", "18:00", "regular", "false"],
      ["Maria Santos", "2024-01-16", "09:00", "18:00", "regular", "false"],
      ["Juan Dela Cruz", "2024-01-15", "08:00", "17:00", "regular", "false"],
    ]
      .map((row) => row.join(","))
      .join("\n")

    const blob = new Blob([csvContent], { type: "text/csv" })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = "schedule-template.csv"
    a.click()
    window.URL.revokeObjectURL(url)
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold text-gray-900">Schedule Management</h2>
          <p className="text-gray-600">{isAdmin ? "Manage employee schedules" : "View your weekly schedule"}</p>
        </div>
        <div className="flex items-center space-x-4">
          <Input
            type="date"
            value={selectedWeek}
            onChange={(e) => setSelectedWeek(getWeekStart(new Date(e.target.value)))}
            className="w-40"
          />
          {isAdmin && (
            <>
              <Button variant="outline" onClick={exportTemplate}>
                <Download className="h-4 w-4 mr-2" />
                Download Template
              </Button>
              <div className="relative">
                <input
                  type="file"
                  accept=".csv"
                  onChange={handleFileUpload}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                />
                <Button variant="outline">
                  <Upload className="h-4 w-4 mr-2" />
                  Import CSV
                </Button>
              </div>
              <Button variant="outline" onClick={() => setRefreshKey((prev) => prev + 1)}>
                <RefreshCw className="h-4 w-4 mr-2" />
                Refresh
              </Button>
              <Button variant="outline" onClick={() => setIsPreviewDialogOpen(true)}>
                <Eye className="h-4 w-4 mr-2" />
                Preview
              </Button>
              <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="h-4 w-4 mr-2" />
                    Add Schedule
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Add Schedule</DialogTitle>
                    <DialogDescription>Create a new schedule entry for an employee.</DialogDescription>
                  </DialogHeader>
                  <form onSubmit={handleSubmit}>
                    <div className="grid gap-4 py-4">
                      <div className="grid gap-2">
                        <Label htmlFor="employee">Employee</Label>
                        <Select
                          value={formData.employeeId}
                          onValueChange={(value) => setFormData({ ...formData, employeeId: value })}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select employee" />
                          </SelectTrigger>
                          <SelectContent>
                            {activeEmployees.map((employee) => (
                              <SelectItem key={employee.id} value={employee.id}>
                                {employee.name} - {employee.position}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="grid gap-2">
                        <Label htmlFor="date">Date</Label>
                        <Input
                          id="date"
                          type="date"
                          value={formData.date}
                          onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                          required
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="grid gap-2">
                          <Label htmlFor="startTime">Start Time</Label>
                          <Input
                            id="startTime"
                            type="time"
                            value={formData.startTime}
                            onChange={(e) => setFormData({ ...formData, startTime: e.target.value })}
                            required
                          />
                        </div>
                        <div className="grid gap-2">
                          <Label htmlFor="endTime">End Time</Label>
                          <Input
                            id="endTime"
                            type="time"
                            value={formData.endTime}
                            max="22:00"
                            onChange={(e) => setFormData({ ...formData, endTime: e.target.value })}
                            required
                          />
                        </div>
                      </div>
                      <div className="grid gap-2">
                        <Label htmlFor="dayType">Day Type</Label>
                        <Select
                          value={formData.dayType}
                          onValueChange={(value: "regular" | "sunday" | "holiday") =>
                            setFormData({ ...formData, dayType: value })
                          }
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="regular">Regular Day</SelectItem>
                            <SelectItem value="sunday">Sunday</SelectItem>
                            <SelectItem value="holiday">Holiday</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <DialogFooter>
                      <Button type="submit">Add Schedule</Button>
                    </DialogFooter>
                  </form>
                </DialogContent>
              </Dialog>
              {/* Edit Dialog */}
              <Dialog open={!!editingSchedule} onOpenChange={() => setEditingSchedule(null)}>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Edit Schedule</DialogTitle>
                    <DialogDescription>Update schedule entry.</DialogDescription>
                  </DialogHeader>
                  <form onSubmit={handleSubmit}>
                    <div className="grid gap-4 py-4">
                      <div className="grid gap-2">
                        <Label htmlFor="edit-employee">Employee</Label>
                        <Select
                          value={formData.employeeId}
                          onValueChange={(value) => setFormData({ ...formData, employeeId: value })}
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {activeEmployees.map((employee) => (
                              <SelectItem key={employee.id} value={employee.id}>
                                {employee.name} - {employee.position}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="grid gap-2">
                        <Label htmlFor="edit-date">Date</Label>
                        <Input
                          id="edit-date"
                          type="date"
                          value={formData.date}
                          onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                          required
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="grid gap-2">
                          <Label htmlFor="edit-startTime">Start Time</Label>
                          <Input
                            id="edit-startTime"
                            type="time"
                            value={formData.startTime}
                            onChange={(e) => setFormData({ ...formData, startTime: e.target.value })}
                            required
                          />
                        </div>
                        <div className="grid gap-2">
                          <Label htmlFor="edit-endTime">End Time</Label>
                          <Input
                            id="edit-endTime"
                            type="time"
                            value={formData.endTime}
                            max="22:00"
                            onChange={(e) => setFormData({ ...formData, endTime: e.target.value })}
                            required
                          />
                        </div>
                      </div>
                      <div className="grid gap-2">
                        <Label htmlFor="edit-dayType">Day Type</Label>
                        <Select
                          value={formData.dayType}
                          onValueChange={(value: "regular" | "sunday" | "holiday") =>
                            setFormData({ ...formData, dayType: value })
                          }
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="regular">Regular Day</SelectItem>
                            <SelectItem value="sunday">Sunday</SelectItem>
                            <SelectItem value="holiday">Holiday</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <DialogFooter>
                      <Button type="button" variant="outline" onClick={() => setEditingSchedule(null)}>
                        Cancel
                      </Button>
                      <Button type="submit">Update Schedule</Button>
                    </DialogFooter>
                  </form>
                </DialogContent>
              </Dialog>
            </>
          )}
        </div>
      </div>

      {/* Preview Dialog */}
      <Dialog open={isPreviewDialogOpen} onOpenChange={setIsPreviewDialogOpen}>
        <DialogContent className="max-w-6xl max-h-[90vh] overflow-auto">
          <DialogHeader>
            <DialogTitle>Weekly Schedule Preview</DialogTitle>
            <DialogDescription>
              Preview of the weekly schedule for {new Date(selectedWeek).toLocaleDateString()} -{" "}
              {new Date(weekDates[6]).toLocaleDateString()}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            {/* Company Header */}
            <div className="text-center border-b pb-4">
              {companySettings.headerUrl && (
                <img
                  src={companySettings.headerUrl || "/placeholder.svg"}
                  alt="Company Header"
                  className="mx-auto mb-2 max-h-20"
                />
              )}
              <div className="flex items-center justify-center space-x-4">
                {companySettings.logoUrl && (
                  <img src={companySettings.logoUrl || "/placeholder.svg"} alt="Company Logo" className="h-12 w-12" />
                )}
                <div>
                  <h1 className="text-2xl font-bold">{companySettings.name || "TimeKo"}</h1>
                  {companySettings.address && <p className="text-sm text-gray-600">{companySettings.address}</p>}
                </div>
              </div>
            </div>

            {/* Schedule Table */}
            <div className="overflow-x-auto">
              <table className="w-full border-collapse border border-gray-300">
                <thead>
                  <tr className="bg-gray-100">
                    <th className="border border-gray-300 p-2 text-left">Employee</th>
                    {weekDates.map((date, index) => (
                      <th key={date} className="border border-gray-300 p-2 text-center min-w-32">
                        <div>
                          <div className="font-semibold">{dayNames[index]}</div>
                          <div className="text-xs text-gray-500">{new Date(date).toLocaleDateString()}</div>
                        </div>
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {activeEmployees.map((employee) => (
                    <tr key={employee.id} className="border-b">
                      <td className="border border-gray-300 p-2">
                        <div>
                          <div className="font-medium">{employee.name}</div>
                          <div className="text-sm text-gray-500">{employee.position}</div>
                        </div>
                      </td>
                      {weekDates.map((date) => {
                        const schedule = getScheduleForDay(employee.id, date)
                        return (
                          <td key={date} className="border border-gray-300 p-2 text-center">
                            {schedule ? (
                              <div className="text-sm">
                                {schedule.startTime} - {schedule.endTime}
                              </div>
                            ) : (
                              <div className="text-gray-400 text-sm">Rest</div>
                            )}
                          </td>
                        )
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsPreviewDialogOpen(false)}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Import Status */}
      {importStatus && (
        <Card
          className={
            importStatus.includes("Error") || importStatus.includes("errors") ? "border-red-300" : "border-green-300"
          }
        >
          <CardContent className="p-4">
            <div className="flex items-start space-x-2">
              <div
                className={`mt-0.5 rounded-full p-1 ${importStatus.includes("Error") || importStatus.includes("errors") ? "bg-red-100 text-red-600" : "bg-green-100 text-green-600"}`}
              >
                {importStatus.includes("Error") || importStatus.includes("errors") ? (
                  <AlertTriangle className="h-4 w-4" />
                ) : (
                  <CheckCircle className="h-4 w-4" />
                )}
              </div>
              <div>
                <p className="text-sm font-medium">Import Status</p>
                <p className="text-sm text-gray-600 whitespace-pre-line">{importStatus}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Import Instructions */}
      {isAdmin && (
        <Card>
          <CardHeader>
            <CardTitle>Excel Import Instructions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 text-sm text-gray-600">
              <p>
                <strong>CSV Format:</strong> Employee Name, Date, Start Time, End Time, Day Type, Is Rest Day
              </p>
              <p>
                <strong>Example:</strong> "Maria Santos,2024-01-15,09:00,18:00,regular,false"
              </p>
              <p>• Employee Name must match exactly with existing employee names</p>
              <p>• Date format: YYYY-MM-DD</p>
              <p>• Time format: HH:MM (24-hour format)</p>
              <p>• Day Type can be "regular", "sunday", or "holiday"</p>
              <p>• Is Rest Day should be "true" or "false"</p>
              <p>• Download the template above for the correct format</p>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Weekly Schedule Grid */}
      <Card key={refreshKey}>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Calendar className="h-5 w-5" />
            <span>Weekly Schedule</span>
          </CardTitle>
          <CardDescription>
            Week of {new Date(selectedWeek).toLocaleDateString()} - {new Date(weekDates[6]).toLocaleDateString()}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr>
                  <th className="text-left p-2 border-b">Employee</th>
                  {weekDates.map((date, index) => (
                    <th key={date} className="text-center p-2 border-b min-w-32">
                      <div>
                        <div className="font-semibold">{dayNames[index]}</div>
                        <div className="text-xs text-gray-500">{new Date(date).toLocaleDateString()}</div>
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {(isAdmin ? activeEmployees : currentEmployee ? [currentEmployee] : []).map((employee) => (
                  <tr key={employee.id} className="border-b">
                    <td className="p-2">
                      <div>
                        <div className="font-medium">{employee.name}</div>
                        <div className="text-sm text-gray-500">{employee.position}</div>
                      </div>
                    </td>
                    {weekDates.map((date) => {
                      const schedule = getScheduleForDay(employee.id, date)
                      const dayIndex = new Date(date).getDay()
                      const isSunday = dayIndex === 0

                      return (
                        <td key={date} className="p-2 text-center">
                          {schedule ? (
                            <div className="space-y-1">
                              <div className="text-sm font-medium">
                                {schedule.startTime} - {schedule.endTime}
                              </div>
                              <div className="flex justify-center">
                                <Badge
                                  variant={
                                    schedule.dayType === "holiday"
                                      ? "destructive"
                                      : schedule.dayType === "sunday" || isSunday
                                        ? "secondary"
                                        : "default"
                                  }
                                  className="text-xs"
                                >
                                  {schedule.dayType === "holiday"
                                    ? "Holiday"
                                    : schedule.dayType === "sunday" || isSunday
                                      ? "Sunday"
                                      : "Regular"}
                                </Badge>
                              </div>
                              <div className="text-xs text-gray-500">
                                {(() => {
                                  const [startHour, startMin] = schedule.startTime.split(":").map(Number)
                                  const [endHour, endMin] = schedule.endTime.split(":").map(Number)
                                  const totalMinutes = endHour * 60 + endMin - (startHour * 60 + startMin) - 60
                                  return `${(totalMinutes / 60).toFixed(1)}h`
                                })()}
                              </div>
                              {isAdmin && (
                                <div className="flex justify-center space-x-1 mt-1">
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={() => handleEditSchedule(schedule)}
                                    className="h-6 w-12 text-xs"
                                  >
                                    Edit
                                  </Button>
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={() => handleDeleteSchedule(schedule.id)}
                                    className="h-6 w-12 text-xs text-red-600"
                                  >
                                    Del
                                  </Button>
                                </div>
                              )}
                            </div>
                          ) : (
                            <div className="text-gray-400 text-sm">Rest Day</div>
                          )}
                        </td>
                      )
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Schedule Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Scheduled Hours</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {schedules
                .filter((schedule) => {
                  const scheduleDate = new Date(schedule.date)
                  const weekStart = new Date(selectedWeek)
                  const weekEnd = new Date(weekStart)
                  weekEnd.setDate(weekStart.getDate() + 6)
                  return (
                    scheduleDate >= weekStart &&
                    scheduleDate <= weekEnd &&
                    (!isAdmin || !currentEmployee || schedule.employeeId === currentEmployee.id) &&
                    schedule.isActive !== false
                  )
                })
                .reduce((total, schedule) => {
                  const [startHour, startMin] = schedule.startTime.split(":").map(Number)
                  const [endHour, endMin] = schedule.endTime.split(":").map(Number)
                  const totalMinutes = endHour * 60 + endMin - (startHour * 60 + startMin) - 60
                  return total + totalMinutes / 60
                }, 0)
                .toFixed(1)}
            </div>
            <p className="text-xs text-muted-foreground">This week</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Working Days</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {
                schedules.filter((schedule) => {
                  const scheduleDate = new Date(schedule.date)
                  const weekStart = new Date(selectedWeek)
                  const weekEnd = new Date(weekStart)
                  weekEnd.setDate(weekStart.getDate() + 6)
                  return (
                    scheduleDate >= weekStart &&
                    scheduleDate <= weekEnd &&
                    (!isAdmin || !currentEmployee || schedule.employeeId === currentEmployee.id) &&
                    schedule.isActive !== false
                  )
                }).length
              }
            </div>
            <p className="text-xs text-muted-foreground">Scheduled days</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Special Days</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {
                schedules.filter((schedule) => {
                  const scheduleDate = new Date(schedule.date)
                  const weekStart = new Date(selectedWeek)
                  const weekEnd = new Date(weekStart)
                  weekEnd.setDate(weekStart.getDate() + 6)
                  return (
                    scheduleDate >= weekStart &&
                    scheduleDate <= weekEnd &&
                    (schedule.dayType === "sunday" || schedule.dayType === "holiday") &&
                    (!isAdmin || !currentEmployee || schedule.employeeId === currentEmployee.id) &&
                    schedule.isActive !== false
                  )
                }).length
              }
            </div>
            <p className="text-xs text-muted-foreground">Sunday/Holiday shifts</p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
